# مفكرتي - Mufakarti

مشروع Android جاهز للبناء عبر GitHub Actions.

## بناء APK
1. ارفع محتويات هذا المجلد إلى مستودع GitHub.
2. افتح Actions.
3. اختر Build Mufakarti APK.
4. اضغط Run workflow.
5. بعد نجاح البناء افتح Artifacts وحمّل Mufakarti-debug-apk.

المطور: علاوي النعيمي
