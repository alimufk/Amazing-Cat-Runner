# مفكرتي (My Notebook) - Specification Document

## 1. Concept & Vision

مفكرتي is a premium, Arabic-first digital notebook that serves as your central hub for notes, tasks, ideas, and daily journaling. The app feels like a beautifully crafted leather journal meets modern technology - warm, inviting, and deeply personal. Every interaction should feel intentional and satisfying, encouraging users to capture their thoughts effortlessly.

The design philosophy embraces **calm productivity** - no clutter, no overwhelm, just a serene space where ideas flow freely.

## 2. Design Language

### Aesthetic Direction
Inspired by premium stationery and modern Arabic calligraphy - clean, elegant, with subtle textures and warm tones. Think Moleskin notebook meets Apple Notes.

### Color Palette

**Light Mode:**
- Primary: #6366F1 (Indigo)
- Secondary: #8B5CF6 (Purple)
- Accent: #F59E0B (Amber)
- Background: #F8FAFC
- Surface: #FFFFFF
- Text Primary: #1E293B
- Text Secondary: #64748B
- Border: #E2E8F0
- Success: #10B981
- Warning: #F59E0B
- Error: #EF4444

**Dark Mode:**
- Primary: #818CF8
- Secondary: #A78BFA
- Accent: #FBBF24
- Background: #0F172A
- Surface: #1E293B
- Text Primary: #F1F5F9
- Text Secondary: #94A3B8
- Border: #334155
- Success: #34D399
- Warning: #FBBF24
- Error: #F87171

### Typography
- Arabic: 'IBM Plex Sans Arabic', 'Noto Sans Arabic', sans-serif
- English: 'Inter', system-ui, sans-serif
- Headings: Bold 600-700
- Body: Regular 400
- Sizes: 12px, 14px, 16px, 18px, 20px, 24px, 32px

### Spatial System
- Base unit: 4px
- Spacing scale: 4, 8, 12, 16, 20, 24, 32, 40, 48, 64
- Border radius: 8px (small), 12px (medium), 16px (large), 24px (xl)
- Card shadows: subtle layered shadows for depth

### Motion Philosophy
- Micro-interactions: 150ms ease-out
- Page transitions: 300ms ease-in-out
- List animations: staggered 50ms delay
- Save indicator: fade in/out 200ms
- All animations respect reduced-motion preference

## 3. Layout & Structure

### Navigation
Bottom navigation bar with 5 items:
- 🏠 الرئيسية (Home)
- 📝 الملاحظات (Notes)
- ✅ المهام (Tasks)
- 📅 التقويم (Calendar)
- ⚙️ الإعدادات (Settings)

### FAB
Floating action button at bottom-right for quick note creation.

### Page Structure
- Full-height layouts with safe area padding
- Sticky headers with blur backdrop
- Pull-to-refresh gesture support
- Infinite scroll for long lists

### Responsive Strategy
- Mobile-first (320px-480px)
- Tablet optimization (768px+)
- Touch targets minimum 44px

## 4. Features & Interactions

### Home Dashboard
- Search bar with instant results
- Quick stats (total notes, tasks today, reminders)
- Pinned notes carousel
- Recent notes grid/list
- Category shortcuts
- Quick actions

### Note Editor
- Inline title editing
- Rich text toolbar (sticky on scroll)
- Auto-save with "تم الحفظ" indicator
- Tag input with suggestions
- Category selector
- Color picker (12 preset colors)
- Action menu (pin, favorite, archive, reminder)

### Categories
- Default: شخصي, دراسة, عمل, أفكار, مهام, تسوق, سفر, أخرى
- Custom category creation with icon/color
- Category management (edit, delete, reorder)

### Search
- Full-text search across titles, content, tags
- Filter chips (الكل, المفضلة, المثبتة, المؤرشفة, مع التذكيرات)
- Recent searches
- Search suggestions

### Tasks
- Interactive checkboxes
- Progress indicator
- Drag-to-reorder
- Due date support
- Priority levels
- Subtasks

### Reminders
- Date/time picker
- Repeat options (once, daily, weekly, monthly)
- Local notifications (where supported)

### Journal
- Daily entry editor
- Calendar navigation
- Mood tracking (optional)
- Photo attachments

### Calendar View
- Monthly calendar grid
- Daily detail view
- Notes/tasks/reminders indicators
- Quick add from date

### Settings
- Appearance (theme, accent, font size)
- Language (AR/EN)
- Notes defaults
- Notification preferences
- Security (PIN, biometric)
- Data management (backup, restore, export, import)
- About section

## 5. Component Inventory

### NoteCard
- States: default, hovered, pressed, selected
- Shows: title, preview, date, category badge, color indicator
- Actions: tap to open, long-press for menu

### TaskItem
- States: unchecked, checked, overdue
- Shows: checkbox, text, due date, priority indicator
- Actions: toggle, swipe to delete, drag to reorder

### CategoryChip
- States: default, selected, disabled
- Shows: icon, name, note count
- Actions: tap to filter

### SearchBar
- States: collapsed, expanded, focused
- Shows: search icon, input, clear button, filter button
- Actions: type to search, tap to expand

### EmptyState
- Shows: illustration, title, description, action button
- Variants: no notes, no tasks, empty trash, no results

### BottomNav
- 5 items with icons and labels
- Active state indicator
- Badge support for notifications

### FAB
- Primary action button
- Expandable menu option
- Ripple effect on press

## 6. Technical Approach

### Framework
- React 18 with TypeScript
- Vite for build
- Tailwind CSS for styling

### State Management
- React Context for global state (AppContext, ThemeContext, SettingsContext)
- localStorage for persistence
- Custom hooks for business logic

### Settings System
The app uses a comprehensive settings system with the following features:

**SettingsContext** (`src/context/SettingsContext.tsx`):
- Manages user preferences for font size, accent color, language, theme, and note defaults
- Automatically applies CSS variables to the document root for real-time UI updates
- Persists all settings to localStorage
- Supports three font sizes: Small (14px), Medium (16px), Large (18px)
- Supports 8 accent colors: Indigo, Purple, Pink, Red, Amber, Green, Cyan, Blue
- Provides sync between multiple context providers

**Theme Application**:
- Font size changes apply immediately via CSS custom properties
- Accent color changes update CSS variables and Tailwind utility classes
- Theme modes (Light/Dark/System) are managed by ThemeContext
- All settings persist across app restarts

### Data Model

```typescript
interface Note {
  id: string;
  title: string;
  content: string; // HTML content
  plainText: string; // For search
  type: NoteType;
  categoryId: string;
  color: string;
  isPinned: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  isTrashed: boolean;
  tags: string[];
  reminder: Reminder | null;
  attachments: Attachment[];
  createdAt: number;
  updatedAt: number;
  trashedAt: number | null;
}

interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
  isDefault: boolean;
  order: number;
}

interface Task {
  id: string;
  noteId: string;
  text: string;
  isCompleted: boolean;
  dueDate: number | null;
  priority: 'low' | 'medium' | 'high';
  order: number;
}

interface JournalEntry {
  id: string;
  date: string; // YYYY-MM-DD
  content: string;
  mood: string | null;
  createdAt: number;
  updatedAt: number;
}

interface Reminder {
  dateTime: number;
  repeat: 'once' | 'daily' | 'weekly' | 'monthly';
  isTriggered: boolean;
}

interface Attachment {
  id: string;
  type: 'image' | 'voice' | 'file';
  name: string;
  url: string;
  size: number;
  createdAt: number;
}
```

### Storage
- IndexedDB for large data (notes, attachments)
- localStorage for settings and preferences

### Security
- Optional PIN lock (hashed and stored securely)
- Biometric API where supported
- No plain-text sensitive data

### Offline First
- All core features work offline
- Service worker for PWA support
- Sync-ready architecture (future)

## Credits

### Developer
- **علاوي النعيمي** (Allawi Al-Naimi)