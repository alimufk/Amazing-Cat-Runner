import { Note, Task, NoteType, SearchFilters, JournalEntry } from '../types';

export function formatDate(timestamp: number, lang: 'ar' | 'en' = 'ar'): string {
  const date = new Date(timestamp);
  const options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  };
  return date.toLocaleDateString(lang === 'ar' ? 'ar-SA' : 'en-US', options);
}

export function formatTime(timestamp: number, lang: 'ar' | 'en' = 'ar'): string {
  const date = new Date(timestamp);
  const options: Intl.DateTimeFormatOptions = {
    hour: '2-digit',
    minute: '2-digit',
  };
  return date.toLocaleTimeString(lang === 'ar' ? 'ar-SA' : 'en-US', options);
}

export function formatDateTime(timestamp: number, lang: 'ar' | 'en' = 'ar'): string {
  return `${formatDate(timestamp, lang)} - ${formatTime(timestamp, lang)}`;
}

export function formatRelativeTime(timestamp: number, lang: 'ar' | 'en' = 'ar'): string {
  const now = Date.now();
  const diff = now - timestamp;
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (lang === 'ar') {
    if (seconds < 60) return 'الآن';
    if (minutes < 60) return `منذ ${minutes} دقيقة`;
    if (hours < 24) return `منذ ${hours} ساعة`;
    if (days < 7) return `منذ ${days} يوم`;
    return formatDate(timestamp, lang);
  } else {
    if (seconds < 60) return 'Now';
    if (minutes < 60) return `${minutes} min ago`;
    if (hours < 24) return `${hours} hr ago`;
    if (days < 7) return `${days} days ago`;
    return formatDate(timestamp, lang);
  }
}

export function getDateString(date: Date = new Date()): string {
  return date.toISOString().split('T')[0];
}

export function isToday(timestamp: number): boolean {
  const today = new Date();
  const date = new Date(timestamp);
  return date.toDateString() === today.toDateString();
}

export function isThisWeek(timestamp: number): boolean {
  const now = new Date();
  const date = new Date(timestamp);
  const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
  const weekEnd = new Date(now.setDate(now.getDate() - now.getDay() + 6));
  return date >= weekStart && date <= weekEnd;
}

export function stripHtml(html: string): string {
  const tmp = document.createElement('div');
  tmp.innerHTML = html;
  return tmp.textContent || tmp.innerText || '';
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

export function countWords(text: string): number {
  const clean = stripHtml(text).trim();
  if (!clean) return 0;
  return clean.split(/\s+/).length;
}

export function countCharacters(text: string): number {
  return stripHtml(text).length;
}

export function searchNotes(notes: Note[], filters: SearchFilters): Note[] {
  let filtered = notes.filter(n => !n.isTrashed && !n.isArchived);
  
  if (filters.query) {
    const query = filters.query.toLowerCase();
    filtered = filtered.filter(n => 
      n.title.toLowerCase().includes(query) ||
      n.plainText.toLowerCase().includes(query) ||
      n.tags.some(t => t.toLowerCase().includes(query))
    );
  }
  
  switch (filters.type) {
    case 'favorites':
      filtered = filtered.filter(n => n.isFavorite);
      break;
    case 'pinned':
      filtered = filtered.filter(n => n.isPinned);
      break;
    case 'archived':
      filtered = notes.filter(n => n.isArchived);
      break;
    case 'reminders':
      filtered = filtered.filter(n => n.reminder && n.reminder.dateTime > Date.now());
      break;
  }
  
  if (filters.categoryId) {
    filtered = filtered.filter(n => n.categoryId === filters.categoryId);
  }
  
  return filtered.sort((a, b) => {
    if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
    return b.updatedAt - a.updatedAt;
  });
}

export function getTrashedNotes(notes: Note[]): Note[] {
  return notes
    .filter(n => n.isTrashed)
    .sort((a, b) => (b.trashedAt || 0) - (a.trashedAt || 0));
}

export function calculateTaskProgress(tasks: Task[]): { completed: number; total: number; percentage: number } {
  const total = tasks.length;
  const completed = tasks.filter(t => t.isCompleted).length;
  const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
  return { completed, total, percentage };
}

export function getTasksForDate(tasks: Task[], date: string): Task[] {
  return tasks.filter(t => {
    if (!t.dueDate) return false;
    const taskDate = new Date(t.dueDate).toISOString().split('T')[0];
    return taskDate === date;
  });
}

export function getNotesForDate(notes: Note[], date: string): Note[] {
  return notes.filter(n => {
    const noteDate = new Date(n.createdAt).toISOString().split('T')[0];
    return noteDate === date;
  });
}

export function getJournalForMonth(entries: JournalEntry[], year: number, month: number): JournalEntry[] {
  return entries.filter(e => {
    const [y, m] = e.date.split('-').map(Number);
    return y === year && m === month;
  });
}

export function generateCalendarDays(year: number, month: number): (Date | null)[] {
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const days: (Date | null)[] = [];
  
  // Add empty slots for days before the first day of the month
  for (let i = 0; i < firstDay.getDay(); i++) {
    days.push(null);
  }
  
  // Add all days of the month
  for (let i = 1; i <= lastDay.getDate(); i++) {
    days.push(new Date(year, month, i));
  }
  
  return days;
}

export function getMonthName(month: number, lang: 'ar' | 'en' = 'ar'): string {
  const months = lang === 'ar' 
    ? ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
    : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  return months[month];
}

export function hashPin(pin: string): string {
  // Simple hash for PIN (in production, use proper crypto)
  let hash = 0;
  for (let i = 0; i < pin.length; i++) {
    const char = pin.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return hash.toString(36);
}

export function verifyPin(pin: string, hash: string): boolean {
  return hashPin(pin) === hash;
}

export async function compressImage(file: File, maxWidth = 800, quality = 0.8): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        
        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }
        
        canvas.width = width;
        canvas.height = height;
        
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = reject;
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function downloadFile(content: string, filename: string, type: string): void {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function getNoteTypeIcon(type: NoteType): string {
  const icons: Record<NoteType, string> = {
    text: '📄',
    task: '✅',
    shopping: '🛒',
    ideas: '💡',
    journal: '📔',
    study: '📚',
    work: '💼',
    quick: '⚡',
  };
  return icons[type];
}
