import { Note, Category, Task, JournalEntry, AppSettings, DEFAULT_CATEGORIES } from '../types';

const STORAGE_KEYS = {
  NOTES: 'mufakarti_notes',
  CATEGORIES: 'mufakarti_categories',
  TASKS: 'mufakarti_tasks',
  JOURNAL: 'mufakarti_journal',
  SETTINGS: 'mufakarti_settings',
};

export const defaultSettings: AppSettings = {
  theme: 'system',
  language: 'ar',
  accentColor: '#6366F1',
  fontSize: 'medium',
  defaultCategory: 'personal',
  defaultView: 'grid',
  autoSave: true,
  autoSaveInterval: 2000,
  notificationsEnabled: true,
  appLockEnabled: false,
  pinHash: null,
  biometricEnabled: false,
  defaultNoteColor: '#FFFFFF',
};

// Generic storage helpers
function getItem<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function setItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('Storage error:', error);
  }
}

// Notes
export function getNotes(): Note[] {
  return getItem<Note[]>(STORAGE_KEYS.NOTES, []);
}

export function saveNotes(notes: Note[]): void {
  setItem(STORAGE_KEYS.NOTES, notes);
}

export function getNoteById(id: string): Note | undefined {
  const notes = getNotes();
  return notes.find(n => n.id === id);
}

export function saveNote(note: Note): void {
  const notes = getNotes();
  const index = notes.findIndex(n => n.id === note.id);
  if (index >= 0) {
    notes[index] = note;
  } else {
    notes.unshift(note);
  }
  saveNotes(notes);
}

export function deleteNote(id: string, permanent = false): void {
  const notes = getNotes();
  if (permanent) {
    const filtered = notes.filter(n => n.id !== id);
    saveNotes(filtered);
  } else {
    const updated = notes.map(n => 
      n.id === id ? { ...n, isTrashed: true, trashedAt: Date.now() } : n
    );
    saveNotes(updated);
  }
}

export function restoreNote(id: string): void {
  const notes = getNotes();
  const updated = notes.map(n => 
    n.id === id ? { ...n, isTrashed: false, trashedAt: null } : n
  );
  saveNotes(updated);
}

// Categories
export function getCategories(): Category[] {
  const categories = getItem<Category[]>(STORAGE_KEYS.CATEGORIES, []);
  if (categories.length === 0) {
    saveCategories(DEFAULT_CATEGORIES);
    return DEFAULT_CATEGORIES;
  }
  return categories;
}

export function saveCategories(categories: Category[]): void {
  setItem(STORAGE_KEYS.CATEGORIES, categories);
}

export function saveCategory(category: Category): void {
  const categories = getCategories();
  const index = categories.findIndex(c => c.id === category.id);
  if (index >= 0) {
    categories[index] = category;
  } else {
    categories.push(category);
  }
  saveCategories(categories);
}

export function deleteCategory(id: string): void {
  const categories = getCategories();
  const filtered = categories.filter(c => c.id !== id || c.isDefault);
  saveCategories(filtered);
}

// Tasks
export function getTasks(): Task[] {
  return getItem<Task[]>(STORAGE_KEYS.TASKS, []);
}

export function saveTasks(tasks: Task[]): void {
  setItem(STORAGE_KEYS.TASKS, tasks);
}

export function getTasksByNoteId(noteId: string): Task[] {
  return getTasks().filter(t => t.noteId === noteId);
}

export function saveTask(task: Task): void {
  const tasks = getTasks();
  const index = tasks.findIndex(t => t.id === task.id);
  if (index >= 0) {
    tasks[index] = task;
  } else {
    tasks.push(task);
  }
  saveTasks(tasks);
}

export function deleteTask(id: string): void {
  const tasks = getTasks().filter(t => t.id !== id);
  saveTasks(tasks);
}

export function toggleTask(id: string): void {
  const tasks = getTasks();
  const updated = tasks.map(t => 
    t.id === id ? { ...t, isCompleted: !t.isCompleted } : t
  );
  saveTasks(updated);
}

// Journal
export function getJournalEntries(): JournalEntry[] {
  return getItem<JournalEntry[]>(STORAGE_KEYS.JOURNAL, []);
}

export function saveJournalEntry(entry: JournalEntry): void {
  const entries = getJournalEntries();
  const index = entries.findIndex(e => e.date === entry.date);
  if (index >= 0) {
    entries[index] = entry;
  } else {
    entries.push(entry);
  }
  setItem(STORAGE_KEYS.JOURNAL, entries);
}

export function getJournalByDate(date: string): JournalEntry | undefined {
  return getJournalEntries().find(e => e.date === date);
}

// Settings
export function getSettings(): AppSettings {
  return getItem<AppSettings>(STORAGE_KEYS.SETTINGS, defaultSettings);
}

export function saveSettings(settings: AppSettings): void {
  setItem(STORAGE_KEYS.SETTINGS, settings);
}

export function updateSettings(updates: Partial<AppSettings>): AppSettings {
  const settings = getSettings();
  const updated = { ...settings, ...updates };
  saveSettings(updated);
  return updated;
}

// Export/Import
export function exportData(): string {
  const data = {
    notes: getNotes(),
    categories: getCategories(),
    tasks: getTasks(),
    journal: getJournalEntries(),
    settings: getSettings(),
    exportedAt: Date.now(),
    version: '1.0.0',
  };
  return JSON.stringify(data, null, 2);
}

export function importData(jsonString: string): { success: boolean; message: string } {
  try {
    const data = JSON.parse(jsonString);
    
    if (data.notes && Array.isArray(data.notes)) {
      const existingNotes = getNotes();
      const newNotes = data.notes.filter((n: Note) => !existingNotes.find(e => e.id === n.id));
      saveNotes([...existingNotes, ...newNotes]);
    }
    
    if (data.categories && Array.isArray(data.categories)) {
      saveCategories(data.categories);
    }
    
    if (data.tasks && Array.isArray(data.tasks)) {
      const existingTasks = getTasks();
      const newTasks = data.tasks.filter((t: Task) => !existingTasks.find(e => e.id === t.id));
      saveTasks([...existingTasks, ...newTasks]);
    }
    
    if (data.journal && Array.isArray(data.journal)) {
      const existingJournal = getJournalEntries();
      const newJournal = data.journal.filter((j: JournalEntry) => 
        !existingJournal.find(e => e.date === j.date)
      );
      setItem(STORAGE_KEYS.JOURNAL, [...existingJournal, ...newJournal]);
    }
    
    return { success: true, message: 'تم استيراد البيانات بنجاح' };
  } catch {
    return { success: false, message: 'حدث خطأ أثناء استيراد البيانات' };
  }
}

export function clearAllData(): void {
  localStorage.removeItem(STORAGE_KEYS.NOTES);
  localStorage.removeItem(STORAGE_KEYS.CATEGORIES);
  localStorage.removeItem(STORAGE_KEYS.TASKS);
  localStorage.removeItem(STORAGE_KEYS.JOURNAL);
  saveCategories(DEFAULT_CATEGORIES);
}

// Generate unique ID
export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}
