import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { AppSettings } from '../types';
import { getSettings, saveSettings, defaultSettings } from '../utils/storage';

interface SettingsContextType {
  settings: AppSettings;
  updateSettings: (updates: Partial<AppSettings>) => void;
  isLoaded: boolean;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load settings on mount
  useEffect(() => {
    const savedSettings = getSettings();
    setSettings(savedSettings);
    setIsLoaded(true);
  }, []);

  // Apply settings to DOM when they change
  useEffect(() => {
    if (!isLoaded) return;

    // Apply font size
    const fontSizeMap: Record<string, string> = {
      small: '14px',
      medium: '16px',
      large: '18px',
    };
    const fontSize = fontSizeMap[settings.fontSize] || '16px';
    document.documentElement.style.setProperty('--font-size-base', fontSize);
    document.body.style.fontSize = fontSize;

    // Apply accent color - update CSS variables on root
    document.documentElement.style.setProperty('--accent-color', settings.accentColor);
    document.documentElement.style.setProperty('--primary-color', settings.accentColor);
    
    // Also update data attribute for CSS selectors
    document.documentElement.setAttribute('data-accent-color', settings.accentColor);
    document.documentElement.setAttribute('data-font-size', settings.fontSize);

  }, [settings, isLoaded]);

  const updateSettings = useCallback((updates: Partial<AppSettings>) => {
    setSettings(prev => {
      const newSettings = { ...prev, ...updates };
      saveSettings(newSettings);
      return newSettings;
    });
  }, []);

  return (
    <SettingsContext.Provider value={{ settings, updateSettings, isLoaded }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within SettingsProvider');
  }
  return context;
}
