import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { Note, Category, Task, JournalEntry, AppSettings, SearchFilters } from '../types';
import * as storage from '../utils/storage';

interface AppState {
  notes: Note[];
  categories: Category[];
  tasks: Task[];
  journal: JournalEntry[];
  settings: AppSettings;
  searchFilters: SearchFilters;
  isLoading: boolean;
  currentView: 'home' | 'notes' | 'tasks' | 'calendar' | 'settings' | 'editor' | 'search' | 'trash' | 'archive' | 'journal';
  editingNoteId: string | null;
  selectedDate: string | null;
}

type AppAction =
  | { type: 'LOAD_DATA'; payload: Partial<AppState> }
  | { type: 'SET_VIEW'; payload: AppState['currentView'] }
  | { type: 'SET_NOTES'; payload: Note[] }
  | { type: 'ADD_NOTE'; payload: Note }
  | { type: 'UPDATE_NOTE'; payload: Note }
  | { type: 'DELETE_NOTE'; payload: string }
  | { type: 'RESTORE_NOTE'; payload: string }
  | { type: 'PERMANENT_DELETE_NOTE'; payload: string }
  | { type: 'SET_CATEGORIES'; payload: Category[] }
  | { type: 'ADD_CATEGORY'; payload: Category }
  | { type: 'UPDATE_CATEGORY'; payload: Category }
  | { type: 'DELETE_CATEGORY'; payload: string }
  | { type: 'SET_TASKS'; payload: Task[] }
  | { type: 'ADD_TASK'; payload: Task }
  | { type: 'UPDATE_TASK'; payload: Task }
  | { type: 'DELETE_TASK'; payload: string }
  | { type: 'TOGGLE_TASK'; payload: string }
  | { type: 'SET_JOURNAL'; payload: JournalEntry[] }
  | { type: 'UPDATE_JOURNAL'; payload: JournalEntry }
  | { type: 'UPDATE_SETTINGS'; payload: Partial<AppSettings> }
  | { type: 'SET_SEARCH_FILTERS'; payload: SearchFilters }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_EDITING_NOTE'; payload: string | null }
  | { type: 'SET_SELECTED_DATE'; payload: string | null }
  | { type: 'EMPTY_TRASH' };

const initialState: AppState = {
  notes: [],
  categories: [],
  tasks: [],
  journal: [],
  settings: storage.defaultSettings,
  searchFilters: { query: '', type: 'all', categoryId: null, dateRange: null },
  isLoading: true,
  currentView: 'home',
  editingNoteId: null,
  selectedDate: null,
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'LOAD_DATA':
      return { ...state, ...action.payload, isLoading: false };
    
    case 'SET_VIEW':
      return { ...state, currentView: action.payload };
    
    case 'SET_NOTES':
      return { ...state, notes: action.payload };
    
    case 'ADD_NOTE':
      return { ...state, notes: [action.payload, ...state.notes] };
    
    case 'UPDATE_NOTE':
      return {
        ...state,
        notes: state.notes.map(n => n.id === action.payload.id ? action.payload : n),
      };
    
    case 'DELETE_NOTE':
      return {
        ...state,
        notes: state.notes.map(n => 
          n.id === action.payload ? { ...n, isTrashed: true, trashedAt: Date.now() } : n
        ),
      };
    
    case 'RESTORE_NOTE':
      return {
        ...state,
        notes: state.notes.map(n => 
          n.id === action.payload ? { ...n, isTrashed: false, trashedAt: null } : n
        ),
      };
    
    case 'PERMANENT_DELETE_NOTE':
      return { ...state, notes: state.notes.filter(n => n.id !== action.payload) };
    
    case 'EMPTY_TRASH':
      return { ...state, notes: state.notes.filter(n => !n.isTrashed) };
    
    case 'SET_CATEGORIES':
      return { ...state, categories: action.payload };
    
    case 'ADD_CATEGORY':
      return { ...state, categories: [...state.categories, action.payload] };
    
    case 'UPDATE_CATEGORY':
      return {
        ...state,
        categories: state.categories.map(c => c.id === action.payload.id ? action.payload : c),
      };
    
    case 'DELETE_CATEGORY':
      return { ...state, categories: state.categories.filter(c => c.id !== action.payload) };
    
    case 'SET_TASKS':
      return { ...state, tasks: action.payload };
    
    case 'ADD_TASK':
      return { ...state, tasks: [...state.tasks, action.payload] };
    
    case 'UPDATE_TASK':
      return {
        ...state,
        tasks: state.tasks.map(t => t.id === action.payload.id ? action.payload : t),
      };
    
    case 'DELETE_TASK':
      return { ...state, tasks: state.tasks.filter(t => t.id !== action.payload) };
    
    case 'TOGGLE_TASK':
      return {
        ...state,
        tasks: state.tasks.map(t => 
          t.id === action.payload ? { ...t, isCompleted: !t.isCompleted } : t
        ),
      };
    
    case 'SET_JOURNAL':
      return { ...state, journal: action.payload };
    
    case 'UPDATE_JOURNAL':
      const existing = state.journal.findIndex(j => j.date === action.payload.date);
      if (existing >= 0) {
        const updated = [...state.journal];
        updated[existing] = action.payload;
        return { ...state, journal: updated };
      }
      return { ...state, journal: [...state.journal, action.payload] };
    
    case 'UPDATE_SETTINGS':
      return { ...state, settings: { ...state.settings, ...action.payload } };
    
    case 'SET_SEARCH_FILTERS':
      return { ...state, searchFilters: action.payload };
    
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    
    case 'SET_EDITING_NOTE':
      return { ...state, editingNoteId: action.payload };
    
    case 'SET_SELECTED_DATE':
      return { ...state, selectedDate: action.payload };
    
    default:
      return state;
  }
}

interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  // Helper functions
  createNote: (note: Partial<Note>) => Note;
  updateNote: (note: Note) => void;
  deleteNote: (id: string) => void;
  restoreNote: (id: string) => void;
  permanentDeleteNote: (id: string) => void;
  emptyTrash: () => void;
  togglePin: (id: string) => void;
  toggleFavorite: (id: string) => void;
  toggleArchive: (id: string) => void;
  createCategory: (category: Partial<Category>) => void;
  updateCategory: (category: Category) => void;
  deleteCategory: (id: string) => void;
  createTask: (task: Partial<Task>) => void;
  updateTask: (task: Task) => void;
  deleteTask: (id: string) => void;
  toggleTask: (id: string) => void;
  updateJournal: (entry: JournalEntry) => void;
  setView: (view: AppState['currentView']) => void;
  openEditor: (noteId?: string) => void;
  closeEditor: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Load data on mount
  useEffect(() => {
    const notes = storage.getNotes();
    const categories = storage.getCategories();
    const tasks = storage.getTasks();
    const journal = storage.getJournalEntries();
    const settings = storage.getSettings();

    dispatch({
      type: 'LOAD_DATA',
      payload: { notes, categories, tasks, journal, settings },
    });
  }, []);

  // Save notes whenever they change
  useEffect(() => {
    if (!state.isLoading) {
      storage.saveNotes(state.notes);
    }
  }, [state.notes, state.isLoading]);

  // Save categories whenever they change
  useEffect(() => {
    if (!state.isLoading) {
      storage.saveCategories(state.categories);
    }
  }, [state.categories, state.isLoading]);

  // Save tasks whenever they change
  useEffect(() => {
    if (!state.isLoading) {
      storage.saveTasks(state.tasks);
    }
  }, [state.tasks, state.isLoading]);

  // Save settings whenever they change
  useEffect(() => {
    if (!state.isLoading) {
      storage.saveSettings(state.settings);
    }
  }, [state.settings, state.isLoading]);

  // Journal auto-save
  useEffect(() => {
    if (!state.isLoading && state.journal.length > 0) {
      localStorage.setItem('mufakarti_journal', JSON.stringify(state.journal));
    }
  }, [state.journal, state.isLoading]);

  const createNote = (noteData: Partial<Note>): Note => {
    const note: Note = {
      id: storage.generateId(),
      title: noteData.title || '',
      content: noteData.content || '',
      plainText: noteData.plainText || '',
      type: noteData.type || 'text',
      categoryId: noteData.categoryId || state.settings.defaultCategory,
      color: noteData.color || state.settings.defaultNoteColor,
      isPinned: noteData.isPinned || false,
      isFavorite: noteData.isFavorite || false,
      isArchived: noteData.isArchived || false,
      isTrashed: false,
      tags: noteData.tags || [],
      reminder: noteData.reminder || null,
      attachments: noteData.attachments || [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      trashedAt: null,
      ...noteData,
    };
    dispatch({ type: 'ADD_NOTE', payload: note });
    return note;
  };

  const updateNote = (note: Note) => {
    const updated = { ...note, updatedAt: Date.now() };
    dispatch({ type: 'UPDATE_NOTE', payload: updated });
  };

  const deleteNote = (id: string) => dispatch({ type: 'DELETE_NOTE', payload: id });
  const restoreNote = (id: string) => dispatch({ type: 'RESTORE_NOTE', payload: id });
  const permanentDeleteNote = (id: string) => dispatch({ type: 'PERMANENT_DELETE_NOTE', payload: id });
  const emptyTrash = () => dispatch({ type: 'EMPTY_TRASH' });

  const togglePin = (id: string) => {
    const note = state.notes.find(n => n.id === id);
    if (note) updateNote({ ...note, isPinned: !note.isPinned });
  };

  const toggleFavorite = (id: string) => {
    const note = state.notes.find(n => n.id === id);
    if (note) updateNote({ ...note, isFavorite: !note.isFavorite });
  };

  const toggleArchive = (id: string) => {
    const note = state.notes.find(n => n.id === id);
    if (note) updateNote({ ...note, isArchived: !note.isArchived, isPinned: false });
  };

  const createCategory = (categoryData: Partial<Category>) => {
    const category: Category = {
      id: storage.generateId(),
      name: categoryData.name || '',
      nameEn: categoryData.nameEn || '',
      icon: categoryData.icon || '📁',
      color: categoryData.color || '#6366F1',
      isDefault: false,
      order: state.categories.length,
      ...categoryData,
    };
    dispatch({ type: 'ADD_CATEGORY', payload: category });
  };

  const updateCategory = (category: Category) => {
    dispatch({ type: 'UPDATE_CATEGORY', payload: category });
  };

  const deleteCategory = (id: string) => {
    const category = state.categories.find(c => c.id === id);
    if (category && !category.isDefault) {
      dispatch({ type: 'DELETE_CATEGORY', payload: id });
    }
  };

  const createTask = (taskData: Partial<Task>) => {
    const task: Task = {
      id: storage.generateId(),
      noteId: taskData.noteId || '',
      text: taskData.text || '',
      isCompleted: false,
      dueDate: taskData.dueDate || null,
      priority: taskData.priority || 'medium',
      order: state.tasks.filter(t => t.noteId === taskData.noteId).length,
      createdAt: Date.now(),
      ...taskData,
    };
    dispatch({ type: 'ADD_TASK', payload: task });
  };

  const updateTask = (task: Task) => dispatch({ type: 'UPDATE_TASK', payload: task });
  const deleteTask = (id: string) => dispatch({ type: 'DELETE_TASK', payload: id });
  const toggleTask = (id: string) => dispatch({ type: 'TOGGLE_TASK', payload: id });

  const updateJournal = (entry: JournalEntry) => dispatch({ type: 'UPDATE_JOURNAL', payload: entry });

  const setView = (view: AppState['currentView']) => dispatch({ type: 'SET_VIEW', payload: view });

  const openEditor = (noteId?: string) => {
    dispatch({ type: 'SET_EDITING_NOTE', payload: noteId || null });
    dispatch({ type: 'SET_VIEW', payload: 'editor' });
  };

  const closeEditor = () => {
    dispatch({ type: 'SET_EDITING_NOTE', payload: null });
    dispatch({ type: 'SET_VIEW', payload: 'notes' });
  };

  return (
    <AppContext.Provider value={{
      state,
      dispatch,
      createNote,
      updateNote,
      deleteNote,
      restoreNote,
      permanentDeleteNote,
      emptyTrash,
      togglePin,
      toggleFavorite,
      toggleArchive,
      createCategory,
      updateCategory,
      deleteCategory,
      createTask,
      updateTask,
      deleteTask,
      toggleTask,
      updateJournal,
      setView,
      openEditor,
      closeEditor,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
