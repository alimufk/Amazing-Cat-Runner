import { useState, useEffect, useRef, useCallback, ReactNode } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { SettingsProvider, useSettings } from './context/SettingsContext';
import { Note, Task, NoteType, NOTE_COLORS, NOTE_TYPE_LABELS } from './types';
import { formatDate, formatRelativeTime, getDateString, stripHtml, truncateText, countWords, countCharacters, generateCalendarDays, getMonthName, getNoteTypeIcon, compressImage, downloadFile } from './utils/helpers';
import { exportData, importData } from './utils/storage';

// Icons as SVG components
const Icons = {
  Home: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>,
  Notes: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>,
  Tasks: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg>,
  Calendar: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>,
  Settings: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>,
  Plus: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>,
  Search: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>,
  Back: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>,
  Close: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>,
  Pin: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg>,
  PinFilled: () => <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg>,
  Star: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>,
  StarFilled: () => <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>,
  Archive: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" /></svg>,
  Trash: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>,
  Restore: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>,
  Bold: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 4h8a4 4 0 014 4 4 4 0 01-4 4H6z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 12h9a4 4 0 014 4 4 4 0 01-4 4H6z" /></svg>,
  Italic: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 4h4m-2 0v16m-4 0h4" /></svg>,
  Underline: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4v7a5 5 0 0010 0V4M5 20h14" /></svg>,
  Strikethrough: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v4m0 4v4M5 12h14" /></svg>,
  List: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" /></svg>,
  ListOrdered: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 6h13M7 10h13M7 14h13M7 18h13M4 6h.01M4 10h.01M4 14h.01M4 18h.01" /></svg>,
  AlignLeft: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h10M4 18h14" /></svg>,
  AlignCenter: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M7 12h10M5 18h14" /></svg>,
  AlignRight: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M10 12h10M6 18h14" /></svg>,
  Image: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>,
  Check: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>,
  Grid: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg>,
  ListView: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" /></svg>,
  Moon: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>,
  Sun: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>,
  Download: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>,
  Upload: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>,
  MoreVertical: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" /></svg>,
  ChevronLeft: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>,
  ChevronRight: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>,
  Save: () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>,
  Empty: () => <svg className="w-16 h-16" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>,
  TrashEmpty: () => <svg className="w-16 h-16" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>,
};

// Calculate task progress helper
function calculateProgress(tasks: Task[]) {
  const total = tasks.length;
  const completed = tasks.filter(t => t.isCompleted).length;
  const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
  return { completed, total, percentage };
}

// Main App Component
function AppContent() {
  const { state, setView, openEditor } = useApp();
  const { isDark } = useTheme();

  const navItems = [
    { id: 'home' as const, icon: Icons.Home, label: 'الرئيسية' },
    { id: 'notes' as const, icon: Icons.Notes, label: 'الملاحظات' },
    { id: 'tasks' as const, icon: Icons.Tasks, label: 'المهام' },
    { id: 'calendar' as const, icon: Icons.Calendar, label: 'التقويم' },
    { id: 'settings' as const, icon: Icons.Settings, label: 'الإعدادات' },
  ];

  if (state.isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-indigo-500 rounded-2xl flex items-center justify-center text-white text-3xl font-bold mb-4 mx-auto animate-pulse">
            م
          </div>
          <p className="text-gray-500">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDark ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'}`}>
      <main className="pb-20 min-h-screen">
        {state.currentView === 'home' && <HomeScreen />}
        {state.currentView === 'notes' && <NotesScreen />}
        {state.currentView === 'tasks' && <TasksScreen />}
        {state.currentView === 'calendar' && <CalendarScreen />}
        {state.currentView === 'settings' && <SettingsScreen />}
        {state.currentView === 'editor' && <EditorScreen />}
        {state.currentView === 'search' && <SearchScreen />}
        {state.currentView === 'trash' && <TrashScreen />}
        {state.currentView === 'archive' && <ArchiveScreen />}
        {state.currentView === 'journal' && <JournalScreen />}
      </main>

      {state.currentView !== 'editor' && state.currentView !== 'search' && (
        <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-40">
          <div className="flex justify-around items-center h-16">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                className={`flex flex-col items-center justify-center w-full h-full transition-colors ${
                  state.currentView === item.id
                    ? 'text-indigo-500'
                    : 'text-gray-500 dark:text-gray-400'
                }`}
              >
                <item.icon />
                <span className="text-xs mt-1 font-medium">{item.label}</span>
              </button>
            ))}
          </div>
        </nav>
      )}

      {state.currentView !== 'editor' && state.currentView !== 'search' && (
        <button
          onClick={() => openEditor()}
          className="fixed bottom-20 left-4 w-14 h-14 bg-indigo-500 hover:bg-indigo-600 text-white rounded-full shadow-lg flex items-center justify-center z-30 transition-all active:scale-95"
          style={{ right: 'auto' }}
        >
          <Icons.Plus />
        </button>
      )}
    </div>
  );
}

// Home Screen
function HomeScreen() {
  const { state, setView, openEditor, togglePin, toggleFavorite, toggleArchive, deleteNote } = useApp();
  const lang = state.settings.language;

  const activeNotes = state.notes.filter(n => !n.isTrashed && !n.isArchived);
  const pinnedNotes = activeNotes.filter(n => n.isPinned);
  const recentNotes = [...activeNotes].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 5);
  const trashedCount = state.notes.filter(n => n.isTrashed).length;
  const archivedCount = state.notes.filter(n => n.isArchived).length;

  const getCategoryName = (id: string) => {
    const cat = state.categories.find(c => c.id === id);
    return cat ? (lang === 'ar' ? cat.name : cat.nameEn) : '';
  };

  return (
    <div className="p-4 animate-fadeIn">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-indigo-500">مفكرتي</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {lang === 'ar' ? 'ملاحظاتك، مهامك، وأفكارك في مكان واحد' : 'Your notes, tasks, and ideas in one place'}
          </p>
        </div>
        <button
          onClick={() => setView('search')}
          className="w-10 h-10 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center"
        >
          <Icons.Search />
        </button>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm">
          <p className="text-2xl font-bold text-indigo-500">{activeNotes.length}</p>
          <p className="text-xs text-gray-500 dark:text-gray-400">{lang === 'ar' ? 'ملاحظة' : 'Notes'}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm">
          <p className="text-2xl font-bold text-green-500">{state.tasks.filter(t => !t.isCompleted).length}</p>
          <p className="text-xs text-gray-500 dark:text-gray-400">{lang === 'ar' ? 'مهمة' : 'Tasks'}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm">
          <p className="text-2xl font-bold text-amber-500">
            {activeNotes.filter(n => n.reminder && n.reminder.dateTime > Date.now()).length}
          </p>
          <p className="text-xs text-gray-500 dark:text-gray-400">{lang === 'ar' ? 'تذكير' : 'Reminders'}</p>
        </div>
      </div>

      <div className="flex gap-3 mb-6 overflow-x-auto pb-2">
        <button
          onClick={() => openEditor()}
          className="flex items-center gap-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-4 py-2 rounded-full whitespace-nowrap"
        >
          <Icons.Plus /> {lang === 'ar' ? 'ملاحظة سريعة' : 'Quick Note'}
        </button>
        <button
          onClick={() => setView('journal')}
          className="flex items-center gap-2 bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 px-4 py-2 rounded-full whitespace-nowrap"
        >
          📔 {lang === 'ar' ? 'يوميات' : 'Journal'}
        </button>
      </div>

      {pinnedNotes.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
            <Icons.PinFilled /> {lang === 'ar' ? 'المثبتة' : 'Pinned'}
          </h2>
          <div className="space-y-2">
            {pinnedNotes.slice(0, 3).map(note => (
              <NoteCard
                key={note.id}
                note={note}
                onOpen={() => openEditor(note.id)}
                onTogglePin={() => togglePin(note.id)}
                onToggleFavorite={() => toggleFavorite(note.id)}
                onArchive={() => toggleArchive(note.id)}
                onDelete={() => deleteNote(note.id)}
                categoryName={getCategoryName(note.categoryId)}
              />
            ))}
          </div>
        </div>
      )}

      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-3">{lang === 'ar' ? 'أحدث الملاحظات' : 'Recent Notes'}</h2>
        {recentNotes.length > 0 ? (
          <div className="space-y-2">
            {recentNotes.map(note => (
              <NoteCard
                key={note.id}
                note={note}
                onOpen={() => openEditor(note.id)}
                onTogglePin={() => togglePin(note.id)}
                onToggleFavorite={() => toggleFavorite(note.id)}
                onArchive={() => toggleArchive(note.id)}
                onDelete={() => deleteNote(note.id)}
                categoryName={getCategoryName(note.categoryId)}
              />
            ))}
          </div>
        ) : (
          <EmptyState
            icon={Icons.Empty}
            title={lang === 'ar' ? 'لا توجد ملاحظات' : 'No notes yet'}
            description={lang === 'ar' ? 'ابدأ بكتابة أول ملاحظة لك' : 'Start writing your first note'}
            action={{ label: lang === 'ar' ? 'إنشاء ملاحظة' : 'Create Note', onClick: () => openEditor() }}
          />
        )}
      </div>

      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-3">{lang === 'ar' ? 'الفئات' : 'Categories'}</h2>
        <div className="grid grid-cols-2 gap-3">
          {state.categories.slice(0, 6).map(cat => {
            const count = activeNotes.filter(n => n.categoryId === cat.id).length;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  setView('notes');
                }}
                className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm text-right hover:shadow-md transition-shadow"
              >
                <span className="text-2xl">{cat.icon}</span>
                <h3 className="font-medium mt-2">{lang === 'ar' ? cat.name : cat.nameEn}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{count} {lang === 'ar' ? 'ملاحظة' : 'notes'}</p>
              </button>
            );
          })}
        </div>
      </div>

      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-3">{lang === 'ar' ? 'أرشيف ومهملات' : 'Archive & Trash'}</h2>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setView('archive')}
            className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm flex items-center gap-3"
          >
            <Icons.Archive />
            <div className="text-right">
              <p className="font-medium">{lang === 'ar' ? 'الأرشيف' : 'Archive'}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">{archivedCount}</p>
            </div>
          </button>
          <button
            onClick={() => setView('trash')}
            className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm flex items-center gap-3"
          >
            <Icons.Trash />
            <div className="text-right">
              <p className="font-medium">{lang === 'ar' ? 'المهملات' : 'Trash'}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">{trashedCount}</p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}

// Notes Screen
function NotesScreen() {
  const { state, openEditor, togglePin, toggleFavorite, toggleArchive, deleteNote } = useApp();
  const lang = state.settings.language;
  const [viewMode, setViewMode] = useState<'grid' | 'list'>(state.settings.defaultView);
  const [filterType, setFilterType] = useState<'all' | 'favorites' | 'pinned' | 'archived'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredNotes = state.notes.filter(n => {
    if (filterType === 'favorites') return !n.isTrashed && !n.isArchived && n.isFavorite;
    if (filterType === 'pinned') return !n.isTrashed && !n.isArchived && n.isPinned;
    if (filterType === 'archived') return n.isArchived;
    return !n.isTrashed && !n.isArchived;
  }).filter(n => !selectedCategory || n.categoryId === selectedCategory);

  const getCategoryName = (id: string) => {
    const cat = state.categories.find(c => c.id === id);
    return cat ? (lang === 'ar' ? cat.name : cat.nameEn) : '';
  };

  return (
    <div className="p-4 animate-fadeIn">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold">{lang === 'ar' ? 'الملاحظات' : 'Notes'}</h1>
        <button
          onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
          className="p-2 rounded-lg bg-gray-100 dark:bg-gray-800"
        >
          {viewMode === 'grid' ? <Icons.ListView /> : <Icons.Grid />}
        </button>
      </div>

      <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
        {[
          { id: 'all', label: lang === 'ar' ? 'الكل' : 'All' },
          { id: 'favorites', label: lang === 'ar' ? 'المفضلة' : 'Favorites' },
          { id: 'pinned', label: lang === 'ar' ? 'المثبتة' : 'Pinned' },
          { id: 'archived', label: lang === 'ar' ? 'الأرشيف' : 'Archived' },
        ].map(filter => (
          <button
            key={filter.id}
            onClick={() => setFilterType(filter.id as typeof filterType)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors ${
              filterType === filter.id
                ? 'bg-indigo-500 text-white'
                : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-3 py-1 rounded-full text-sm whitespace-nowrap ${
            !selectedCategory
              ? 'bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400'
              : 'bg-gray-100 dark:bg-gray-800'
          }`}
        >
          {lang === 'ar' ? 'الكل' : 'All'}
        </button>
        {state.categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3 py-1 rounded-full text-sm whitespace-nowrap flex items-center gap-1 ${
              selectedCategory === cat.id
                ? 'bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400'
                : 'bg-gray-100 dark:bg-gray-800'
            }`}
          >
            <span>{cat.icon}</span>
            <span>{lang === 'ar' ? cat.name : cat.nameEn}</span>
          </button>
        ))}
      </div>

      {filteredNotes.length > 0 ? (
        <div className={viewMode === 'grid' ? 'grid grid-cols-2 gap-3' : 'space-y-2'}>
          {filteredNotes.map(note => (
            <NoteCard
              key={note.id}
              note={note}
              viewMode={viewMode}
              onOpen={() => openEditor(note.id)}
              onTogglePin={() => togglePin(note.id)}
              onToggleFavorite={() => toggleFavorite(note.id)}
              onArchive={() => toggleArchive(note.id)}
              onDelete={() => deleteNote(note.id)}
              categoryName={getCategoryName(note.categoryId)}
            />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Icons.Empty}
          title={lang === 'ar' ? 'لا توجد ملاحظات' : 'No notes'}
          description={lang === 'ar' ? 'اضغط على زر + لإنشاء ملاحظة جديدة' : 'Tap + to create a new note'}
        />
      )}
    </div>
  );
}

// Note Card Component
function NoteCard({
  note,
  viewMode = 'list',
  onOpen,
  onTogglePin,
  onToggleFavorite,
  onArchive,
  onDelete,
  categoryName,
}: {
  note: Note;
  viewMode?: 'grid' | 'list';
  onOpen: () => void;
  onTogglePin: () => void;
  onToggleFavorite: () => void;
  onArchive: () => void;
  onDelete: () => void;
  categoryName?: string;
}) {
  const { state } = useApp();
  const lang = state.settings.language;
  const [showMenu, setShowMenu] = useState(false);
  const preview = truncateText(stripHtml(note.content), viewMode === 'grid' ? 60 : 100);

  return (
    <div
      className={`bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden cursor-pointer hover:shadow-md transition-all ${
        viewMode === 'grid' ? '' : 'flex'
      }`}
      style={{ borderRight: `4px solid ${note.color || '#6366F1'}` }}
      onClick={onOpen}
    >
      <div className={`p-3 ${viewMode === 'grid' ? '' : 'flex-1'}`}>
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            {note.title && (
              <h3 className="font-semibold truncate">{note.title || (lang === 'ar' ? 'بدون عنوان' : 'Untitled')}</h3>
            )}
            {preview && (
              <p className={`text-sm text-gray-500 dark:text-gray-400 mt-1 ${viewMode === 'grid' ? 'line-clamp-2' : 'line-clamp-1'}`}>
                {preview}
              </p>
            )}
            <div className="flex items-center gap-2 mt-2 text-xs text-gray-400">
              <span>{getNoteTypeIcon(note.type)}</span>
              {categoryName && <span>{categoryName}</span>}
              <span>{formatRelativeTime(note.updatedAt, lang)}</span>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {note.isPinned && <span className="text-indigo-500"><Icons.PinFilled /></span>}
            {note.isFavorite && <span className="text-amber-500"><Icons.StarFilled /></span>}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowMenu(!showMenu);
              }}
              className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              <Icons.MoreVertical />
            </button>
          </div>
        </div>
      </div>

      {showMenu && (
        <div className="fixed inset-0 z-50" onClick={() => setShowMenu(false)}>
          <div className="absolute top-0 left-0 right-0 bottom-0 bg-black/20" />
          <div className="absolute bg-white dark:bg-gray-800 rounded-t-xl shadow-lg w-full max-w-md mx-auto bottom-0 left-0 right-0 animate-slideUp">
            <div className="p-4 space-y-1">
              <button
                onClick={(e) => { e.stopPropagation(); onTogglePin(); setShowMenu(false); }}
                className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Icons.Pin /> {note.isPinned ? (lang === 'ar' ? 'إلغاء التثبيت' : 'Unpin') : (lang === 'ar' ? 'تثبيت' : 'Pin')}
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onToggleFavorite(); setShowMenu(false); }}
                className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Icons.Star /> {note.isFavorite ? (lang === 'ar' ? 'إزالة من المفضلة' : 'Unfavorite') : (lang === 'ar' ? 'إضافة للمفضلة' : 'Favorite')}
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onArchive(); setShowMenu(false); }}
                className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Icons.Archive /> {lang === 'ar' ? 'أرشفة' : 'Archive'}
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onDelete(); setShowMenu(false); }}
                className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-red-500"
              >
                <Icons.Trash /> {lang === 'ar' ? 'حذف' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Tasks Screen
function TasksScreen() {
  const { state, createTask, toggleTask, deleteTask, updateTask } = useApp();
  const lang = state.settings.language;
  const [newTaskText, setNewTaskText] = useState('');

  const notesWithTasks = state.notes.filter(n => 
    !n.isTrashed && !n.isArchived && (n.type === 'task' || state.tasks.some(t => t.noteId === n.id))
  );

  const tasksByNote = notesWithTasks.reduce((acc, note) => {
    const noteTasks = state.tasks.filter(t => t.noteId === note.id);
    if (noteTasks.length > 0 || note.type === 'task') {
      acc[note.id] = {
        note,
        tasks: noteTasks,
        progress: calculateProgress(noteTasks),
      };
    }
    return acc;
  }, {} as Record<string, { note: Note; tasks: Task[]; progress: { completed: number; total: number; percentage: number } }>);

  const quickTasks = state.tasks.filter(t => t.noteId === 'quick');

  const handleAddTask = () => {
    if (!newTaskText.trim()) return;
    createTask({
      noteId: 'quick',
      text: newTaskText.trim(),
    });
    setNewTaskText('');
  };

  return (
    <div className="p-4 animate-fadeIn">
      <h1 className="text-xl font-bold mb-4">{lang === 'ar' ? 'المهام' : 'Tasks'}</h1>

      <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm mb-6">
        <div className="flex gap-2">
          <input
            type="text"
            value={newTaskText}
            onChange={(e) => setNewTaskText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddTask()}
            placeholder={lang === 'ar' ? 'إضافة مهمة جديدة...' : 'Add new task...'}
            className="flex-1 bg-gray-50 dark:bg-gray-700 rounded-lg px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            onClick={handleAddTask}
            className="bg-indigo-500 text-white px-4 py-2 rounded-lg"
          >
            <Icons.Plus />
          </button>
        </div>
      </div>

      {quickTasks.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-3">{lang === 'ar' ? 'مهام سريعة' : 'Quick Tasks'}</h2>
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
            {quickTasks.map(task => (
              <TaskItem
                key={task.id}
                task={task}
                onToggle={() => toggleTask(task.id)}
                onDelete={() => deleteTask(task.id)}
                onUpdate={(text) => updateTask({ ...task, text })}
              />
            ))}
          </div>
        </div>
      )}

      {Object.values(tasksByNote).map(({ note, tasks, progress }) => (
        <div key={note.id} className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              {note.isPinned && <Icons.PinFilled />}
              {note.title || (lang === 'ar' ? 'بدون عنوان' : 'Untitled')}
            </h2>
            <span className="text-sm text-gray-500">
              {progress.completed}/{progress.total} ({progress.percentage}%)
            </span>
          </div>
          <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full mb-3 overflow-hidden">
            <div
              className="h-full bg-green-500 transition-all duration-300"
              style={{ width: `${progress.percentage}%` }}
            />
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
            {tasks.map(task => (
              <TaskItem
                key={task.id}
                task={task}
                onToggle={() => toggleTask(task.id)}
                onDelete={() => deleteTask(task.id)}
                onUpdate={(text) => updateTask({ ...task, text })}
              />
            ))}
          </div>
        </div>
      ))}

      {quickTasks.length === 0 && Object.keys(tasksByNote).length === 0 && (
        <EmptyState
          icon={Icons.Tasks}
          title={lang === 'ar' ? 'لا توجد مهام' : 'No tasks'}
          description={lang === 'ar' ? 'أضف مهامك للبدء' : 'Add your first task to get started'}
        />
      )}
    </div>
  );
}

function TaskItem({
  task,
  onToggle,
  onDelete,
  onUpdate,
}: {
  task: Task;
  onToggle: () => void;
  onDelete: () => void;
  onUpdate: (text: string) => void;
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(task.text);

  const handleSave = () => {
    if (editText.trim()) {
      onUpdate(editText.trim());
    }
    setIsEditing(false);
  };

  return (
    <div className={`flex items-center gap-3 p-4 border-b border-gray-100 dark:border-gray-700 last:border-0 ${task.isCompleted ? 'opacity-60' : ''}`}>
      <button
        onClick={onToggle}
        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
          task.isCompleted
            ? 'bg-green-500 border-green-500 text-white'
            : 'border-gray-300 dark:border-gray-600'
        }`}
      >
        {task.isCompleted && <Icons.Check />}
      </button>
      {isEditing ? (
        <input
          type="text"
          value={editText}
          onChange={(e) => setEditText(e.target.value)}
          onBlur={handleSave}
          onKeyDown={(e) => e.key === 'Enter' && handleSave()}
          className="flex-1 bg-transparent outline-none border-b border-indigo-500"
          autoFocus
        />
      ) : (
        <span
          className={`flex-1 cursor-pointer ${task.isCompleted ? 'line-through text-gray-400' : ''}`}
          onDoubleClick={() => setIsEditing(true)}
        >
          {task.text}
        </span>
      )}
      <button onClick={onDelete} className="text-gray-400 hover:text-red-500">
        <Icons.Close />
      </button>
    </div>
  );
}

// Calendar Screen
function CalendarScreen() {
  const { state, setView, openEditor } = useApp();
  const lang = state.settings.language;
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const days = generateCalendarDays(year, month);

  const getNotesForDate = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return state.notes.filter(n => {
      const noteDate = new Date(n.createdAt).toISOString().split('T')[0];
      return noteDate === dateStr && !n.isTrashed && !n.isArchived;
    });
  };

  const getTasksForDate = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return state.tasks.filter(t => {
      if (!t.dueDate) return false;
      const taskDate = new Date(t.dueDate).toISOString().split('T')[0];
      return taskDate === dateStr;
    });
  };

  const selectedDateNotes = selectedDate ? getNotesForDate(new Date(selectedDate)) : [];
  const selectedDateTasks = selectedDate ? getTasksForDate(new Date(selectedDate)) : [];

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

  const isToday = (date: Date) => {
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  return (
    <div className="p-4 animate-fadeIn">
      <h1 className="text-xl font-bold mb-4">{lang === 'ar' ? 'التقويم' : 'Calendar'}</h1>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 mb-4">
        <div className="flex items-center justify-between mb-4">
          <button onClick={prevMonth} className="p-2">
            <Icons.ChevronRight />
          </button>
          <h2 className="text-lg font-semibold">
            {getMonthName(month, lang)} {year}
          </h2>
          <button onClick={nextMonth} className="p-2">
            <Icons.ChevronLeft />
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1 mb-2">
          {(lang === 'ar' ? ['أحد', 'إثن', 'ثلا', 'أرب', 'خمي', 'جمع', 'سبت'] : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']).map(day => (
            <div key={day} className="text-center text-sm text-gray-500 py-2">
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1">
          {days.map((date, i) => {
            if (!date) {
              return <div key={`empty-${i}`} className="aspect-square" />;
            }
            const dateStr = date.toISOString().split('T')[0];
            const hasNotes = getNotesForDate(date).length > 0;
            const hasTasks = getTasksForDate(date).length > 0;
            const isSelected = selectedDate === dateStr;

            return (
              <button
                key={dateStr}
                onClick={() => setSelectedDate(dateStr)}
                className={`aspect-square rounded-lg flex flex-col items-center justify-center relative transition-colors ${
                  isSelected
                    ? 'bg-indigo-500 text-white'
                    : isToday(date)
                    ? 'bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <span className="text-sm">{date.getDate()}</span>
                {(hasNotes || hasTasks) && (
                  <div className="absolute bottom-1 flex gap-0.5">
                    {hasNotes && <div className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-white' : 'bg-indigo-500'}`} />}
                    {hasTasks && <div className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-white' : 'bg-green-500'}`} />}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {selectedDate && (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4">
          <h3 className="font-semibold mb-3">
            {formatDate(new Date(selectedDate).getTime(), lang)}
          </h3>

          {selectedDateTasks.length > 0 && (
            <div className="mb-4">
              <h4 className="text-sm text-gray-500 mb-2">{lang === 'ar' ? 'المهام' : 'Tasks'}</h4>
              {selectedDateTasks.map(task => (
                <div key={task.id} className="flex items-center gap-2 py-1">
                  <div className={`w-2 h-2 rounded-full ${task.isCompleted ? 'bg-green-500' : 'bg-gray-300'}`} />
                  <span className={task.isCompleted ? 'line-through text-gray-400' : ''}>{task.text}</span>
                </div>
              ))}
            </div>
          )}

          {selectedDateNotes.length > 0 && (
            <div>
              <h4 className="text-sm text-gray-500 mb-2">{lang === 'ar' ? 'الملاحظات' : 'Notes'}</h4>
              <div className="space-y-2">
                {selectedDateNotes.map(note => (
                  <button
                    key={note.id}
                    onClick={() => openEditor(note.id)}
                    className="w-full text-right p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <p className="font-medium">{note.title || (lang === 'ar' ? 'بدون عنوان' : 'Untitled')}</p>
                    <p className="text-sm text-gray-500 truncate">
                      {truncateText(stripHtml(note.content), 50)}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {selectedDateTasks.length === 0 && selectedDateNotes.length === 0 && (
            <p className="text-gray-400 text-center py-4">
              {lang === 'ar' ? 'لا توجد عناصر لهذا اليوم' : 'No items for this day'}
            </p>
          )}

          <button
            onClick={() => openEditor()}
            className="w-full mt-4 py-2 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg text-gray-500 hover:border-indigo-500 hover:text-indigo-500 transition-colors"
          >
            + {lang === 'ar' ? 'إضافة ملاحظة' : 'Add Note'}
          </button>
        </div>
      )}

      <button
        onClick={() => setView('journal')}
        className="w-full mt-4 bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 p-4 rounded-xl flex items-center justify-center gap-2"
      >
        📔 {lang === 'ar' ? 'الذهاب إلى اليومية' : 'Go to Journal'}
      </button>
    </div>
  );
}

// Journal Screen
function JournalScreen() {
  const { state, updateJournal, setView } = useApp();
  const lang = state.settings.language;
  const [currentDate, setCurrentDate] = useState(new Date());
  const [content, setContent] = useState('');

  const dateStr = getDateString(currentDate);
  const entry = state.journal.find(j => j.date === dateStr);

  useEffect(() => {
    setContent(entry?.content || '');
  }, [dateStr, entry]);

  const handleSave = useCallback(() => {
    if (content.trim()) {
      updateJournal({
        id: entry?.id || Date.now().toString(),
        date: dateStr,
        content: content,
        plainText: stripHtml(content),
        mood: null,
        createdAt: entry?.createdAt || Date.now(),
        updatedAt: Date.now(),
      });
    }
  }, [content, dateStr, entry, updateJournal]);

  useEffect(() => {
    const timer = setTimeout(handleSave, 1000);
    return () => clearTimeout(timer);
  }, [content, handleSave]);

  const prevDay = () => setCurrentDate(d => new Date(d.getTime() - 86400000));
  const nextDay = () => setCurrentDate(d => new Date(d.getTime() + 86400000));
  const goToToday = () => setCurrentDate(new Date());

  return (
    <div className="p-4 animate-fadeIn">
      <div className="flex items-center justify-between mb-4">
        <button onClick={() => setView('calendar')} className="p-2">
          <Icons.Back />
        </button>
        <h1 className="text-xl font-bold">{lang === 'ar' ? 'اليومية' : 'Journal'}</h1>
        <div className="w-8" />
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 mb-4">
        <div className="flex items-center justify-between">
          <button onClick={prevDay} className="p-2">
            <Icons.ChevronRight />
          </button>
          <div className="text-center">
            <p className="font-semibold">{formatDate(currentDate.getTime(), lang)}</p>
            <button onClick={goToToday} className="text-sm text-indigo-500">
              {lang === 'ar' ? 'اليوم' : 'Today'}
            </button>
          </div>
          <button onClick={nextDay} className="p-2">
            <Icons.ChevronLeft />
          </button>
        </div>
      </div>

      {content !== (entry?.content || '') && (
        <div className="text-center text-sm text-green-500 mb-2 animate-pulse">
          {lang === 'ar' ? 'جاري الحفظ...' : 'Saving...'}
        </div>
      )}

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder={lang === 'ar' ? 'كيف كان يومك؟...' : 'How was your day?...'}
          className="w-full h-96 p-4 bg-transparent outline-none resize-none"
        />
      </div>

      <div className="mt-4 text-center text-sm text-gray-500">
        {countWords(content)} {lang === 'ar' ? 'كلمة' : 'words'} • {countCharacters(content)} {lang === 'ar' ? 'حرف' : 'characters'}
      </div>
    </div>
  );
}

// Settings Screen
function SettingsScreen() {
  const { state, dispatch } = useApp();
  const { setTheme } = useTheme();
  const { settings, updateSettings } = useSettings();
  const lang = settings.language;

  const handleThemeChange = (newTheme: 'light' | 'dark' | 'system') => {
    // Update theme in ThemeContext (saves to localStorage automatically)
    setTheme(newTheme);
    
    // Also update in app settings for persistence (sync both contexts)
    updateSettings({ theme: newTheme });
    dispatch({ type: 'UPDATE_SETTINGS', payload: { ...settings, theme: newTheme } });
  };

  const handleLanguageChange = (language: 'ar' | 'en') => {
    updateSettings({ language });
    dispatch({ type: 'UPDATE_SETTINGS', payload: { ...settings, language } });
  };

  const updateSetting = (key: string, value: unknown) => {
    const updates = { [key]: value };
    dispatch({ type: 'UPDATE_SETTINGS', payload: { ...settings, ...updates } });
    updateSettings(updates);
  };

  const handleExport = (format: 'json' | 'txt') => {
    if (format === 'json') {
      const data = exportData();
      downloadFile(data, `mufakarti-backup-${getDateString()}.json`, 'application/json');
    } else {
      const notes = state.notes.filter(n => !n.isTrashed);
      const text = notes.map(n => `${n.title}\n${stripHtml(n.content)}\n---`).join('\n\n');
      downloadFile(text, `mufakarti-notes-${getDateString()}.txt`, 'text/plain');
    }
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const result = importData(content);
      alert(result.message);
      if (result.success) {
        window.location.reload();
      }
    };
    reader.readAsText(file);
  };

  const handleClearData = () => {
    if (confirm(lang === 'ar' ? 'هل أنت متأكد من حذف جميع البيانات؟' : 'Are you sure you want to delete all data?')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  return (
    <div className="p-4 animate-fadeIn">
      <h1 className="text-xl font-bold mb-6">{lang === 'ar' ? 'الإعدادات' : 'Settings'}</h1>

      <section className="mb-6">
        <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <Icons.Sun /> {lang === 'ar' ? 'المظهر' : 'Appearance'}
        </h2>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
          <div className="p-4 border-b border-gray-100 dark:border-gray-700">
            <p className="font-medium mb-3">{lang === 'ar' ? 'السمة' : 'Theme'}</p>
            <div className="flex gap-2">
              {[
                { id: 'light', label: lang === 'ar' ? 'فاتح' : 'Light', icon: Icons.Sun },
                { id: 'dark', label: lang === 'ar' ? 'داكن' : 'Dark', icon: Icons.Moon },
                { id: 'system', label: lang === 'ar' ? 'النظام' : 'System', icon: Icons.Settings },
              ].map(theme => (
                <button
                  key={theme.id}
                  onClick={() => handleThemeChange(theme.id as 'light' | 'dark' | 'system')}
                  className={`flex-1 p-3 rounded-lg flex flex-col items-center gap-2 transition-all ${
                    settings.theme === theme.id
                      ? 'bg-indigo-500 text-white shadow-md'
                      : 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  <theme.icon />
                  <span className="text-sm">{theme.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="p-4 border-b border-gray-100 dark:border-gray-700">
            <p className="font-medium mb-3">{lang === 'ar' ? 'حجم الخط' : 'Font Size'}</p>
            <div className="flex gap-2">
              {[
                { id: 'small', label: lang === 'ar' ? 'صغير' : 'Small' },
                { id: 'medium', label: lang === 'ar' ? 'متوسط' : 'Medium' },
                { id: 'large', label: lang === 'ar' ? 'كبير' : 'Large' },
              ].map(size => (
                <button
                  key={size.id}
                  onClick={() => updateSetting('fontSize', size.id)}
                  className={`flex-1 p-3 rounded-lg ${
                    settings.fontSize === size.id
                      ? 'bg-indigo-500 text-white'
                      : 'bg-gray-100 dark:bg-gray-700'
                  }`}
                >
                  {size.label}
                </button>
              ))}
            </div>
          </div>

          <div className="p-4">
            <p className="font-medium mb-3">{lang === 'ar' ? 'اللون الرئيسي' : 'Accent Color'}</p>
            <div className="flex gap-2 flex-wrap">
              {['#6366F1', '#8B5CF6', '#EC4899', '#EF4444', '#F59E0B', '#10B981', '#06B6D4', '#3B82F6'].map(color => (
                <button
                  key={color}
                  onClick={() => updateSetting('accentColor', color)}
                  className={`w-10 h-10 rounded-full ${settings.accentColor === color ? 'ring-2 ring-offset-2 ring-gray-400' : ''}`}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mb-6">
        <h2 className="text-lg font-semibold mb-3">🌐 {lang === 'ar' ? 'اللغة' : 'Language'}</h2>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4">
          <div className="flex gap-2">
            <button
              onClick={() => handleLanguageChange('ar')}
              className={`flex-1 p-3 rounded-lg ${
                settings.language === 'ar'
                  ? 'bg-indigo-500 text-white'
                  : 'bg-gray-100 dark:bg-gray-700'
              }`}
            >
              العربية
            </button>
            <button
              onClick={() => handleLanguageChange('en')}
              className={`flex-1 p-3 rounded-lg ${
                settings.language === 'en'
                  ? 'bg-indigo-500 text-white'
                  : 'bg-gray-100 dark:bg-gray-700'
              }`}
            >
              English
            </button>
          </div>
        </div>
      </section>

      <section className="mb-6">
        <h2 className="text-lg font-semibold mb-3">📝 {lang === 'ar' ? 'الملاحظات' : 'Notes'}</h2>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
          <div className="p-4 border-b border-gray-100 dark:border-gray-700">
            <p className="font-medium mb-2">{lang === 'ar' ? 'العرض الافتراضي' : 'Default View'}</p>
            <div className="flex gap-2">
              <button
                onClick={() => updateSetting('defaultView', 'grid')}
                className={`flex-1 p-3 rounded-lg flex items-center justify-center gap-2 ${
                  settings.defaultView === 'grid'
                    ? 'bg-indigo-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-700'
                }`}
              >
                <Icons.Grid /> {lang === 'ar' ? 'شبكة' : 'Grid'}
              </button>
              <button
                onClick={() => updateSetting('defaultView', 'list')}
                className={`flex-1 p-3 rounded-lg flex items-center justify-center gap-2 ${
                  settings.defaultView === 'list'
                    ? 'bg-indigo-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-700'
                }`}
              >
                <Icons.ListView /> {lang === 'ar' ? 'قائمة' : 'List'}
              </button>
            </div>
          </div>
          <div className="p-4 border-b border-gray-100 dark:border-gray-700">
            <p className="font-medium mb-2">{lang === 'ar' ? 'الحفظ التلقائي' : 'Auto Save'}</p>
            <div className="flex items-center justify-between">
              <span className="text-gray-500">{lang === 'ar' ? 'حفظ التغييرات تلقائياً' : 'Save changes automatically'}</span>
              <button
                onClick={() => updateSetting('autoSave', !settings.autoSave)}
                className={`w-12 h-6 rounded-full transition-colors ${
                  settings.autoSave ? 'bg-indigo-500' : 'bg-gray-300'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full shadow transition-transform ${
                  settings.autoSave ? 'translate-x-6' : 'translate-x-0.5'
                }`} />
              </button>
            </div>
          </div>
          <div className="p-4">
            <p className="font-medium mb-2">{lang === 'ar' ? 'الفئة الافتراضية' : 'Default Category'}</p>
            <select
              value={settings.defaultCategory}
              onChange={(e) => updateSetting('defaultCategory', e.target.value)}
              className="w-full p-3 rounded-lg bg-gray-100 dark:bg-gray-700 outline-none"
            >
              {state.categories.map(cat => (
                <option key={cat.id} value={cat.id}>
                  {cat.icon} {lang === 'ar' ? cat.name : cat.nameEn}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      <section className="mb-6">
        <h2 className="text-lg font-semibold mb-3">💾 {lang === 'ar' ? 'البيانات' : 'Data'}</h2>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden space-y-1">
          <button
            onClick={() => handleExport('json')}
            className="w-full p-4 flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-700 text-right"
          >
            <Icons.Download /> {lang === 'ar' ? 'تصدير كـ JSON' : 'Export as JSON'}
          </button>
          <button
            onClick={() => handleExport('txt')}
            className="w-full p-4 flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-700 text-right"
          >
            <Icons.Download /> {lang === 'ar' ? 'تصدير كـ TXT' : 'Export as TXT'}
          </button>
          <label className="w-full p-4 flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer">
            <Icons.Upload /> {lang === 'ar' ? 'استيراد من JSON' : 'Import from JSON'}
            <input type="file" accept=".json" onChange={handleImport} className="hidden" />
          </label>
          <button
            onClick={handleClearData}
            className="w-full p-4 flex items-center gap-3 hover:bg-gray-100 dark:hover:bg-gray-700 text-red-500 text-right"
          >
            <Icons.Trash /> {lang === 'ar' ? 'حذف جميع البيانات' : 'Delete All Data'}
          </button>
        </div>
      </section>

      <section className="mb-6">
        <h2 className="text-lg font-semibold mb-3">ℹ️ {lang === 'ar' ? 'حول' : 'About'}</h2>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center text-white text-2xl font-bold mx-auto mb-3 shadow-lg">
            م
          </div>
          <h3 className="font-bold text-lg">مفكرتي</h3>
          <p className="text-sm text-gray-500 mb-1">Version 1.0.0</p>
          <p className="text-sm text-gray-500 mb-3">
            {lang === 'ar' ? 'ملاحظاتك، مهامك، وأفكارك في مكان واحد' : 'Your notes, tasks, and ideas in one place'}
          </p>
          <div className="pt-3 border-t border-gray-200 dark:border-gray-700">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {lang === 'ar' ? 'المطور' : 'Developer'}: <span className="font-semibold text-indigo-500">علاوي النعيمي</span>
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

// Editor Screen
function EditorScreen() {
  const { state, closeEditor, createNote, updateNote, togglePin, toggleFavorite, dispatch } = useApp();
  const lang = state.settings.language;
  
  const existingNote = state.editingNoteId ? state.notes.find(n => n.id === state.editingNoteId) : null;
  const [note, setNote] = useState<Partial<Note>>(existingNote || {
    title: '',
    content: '',
    type: 'text',
    categoryId: state.settings.defaultCategory,
    color: state.settings.defaultNoteColor,
  });
  const [isSaving, setIsSaving] = useState(false);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showCategoryPicker, setShowCategoryPicker] = useState(false);
  const [showTypePicker, setShowTypePicker] = useState(false);
  const [tagInput, setTagInput] = useState('');
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (existingNote) {
      setNote(existingNote);
      if (contentRef.current) {
        contentRef.current.innerHTML = existingNote.content;
      }
    }
  }, [existingNote]);

  const handleSave = useCallback(() => {
    if (!state.settings.autoSave) return;
    
    setIsSaving(true);
    const content = contentRef.current?.innerHTML || '';
    const plainText = stripHtml(content);
    
    const noteData = {
      ...note,
      content,
      plainText,
      updatedAt: Date.now(),
    };

    if (existingNote) {
      updateNote({ ...existingNote, ...noteData } as Note);
    } else {
      const newNote = createNote(noteData);
      dispatch({ type: 'SET_EDITING_NOTE', payload: newNote.id });
    }

    setTimeout(() => setIsSaving(false), 500);
  }, [note, existingNote, state.settings.autoSave, createNote, updateNote, dispatch]);

  useEffect(() => {
    const timer = setTimeout(handleSave, state.settings.autoSaveInterval || 2000);
    return () => clearTimeout(timer);
  }, [note, handleSave, state.settings.autoSaveInterval]);

  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    contentRef.current?.focus();
  };

  const handleContentChange = () => {
    const content = contentRef.current?.innerHTML || '';
    setNote(prev => ({ ...prev, content }));
  };

  const addTag = () => {
    if (tagInput.trim() && !note.tags?.includes(tagInput.trim())) {
      setNote(prev => ({
        ...prev,
        tags: [...(prev.tags || []), tagInput.trim()],
      }));
      setTagInput('');
    }
  };

  const removeTag = (tag: string) => {
    setNote(prev => ({
      ...prev,
      tags: (prev.tags || []).filter(t => t !== tag),
    }));
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    try {
      const compressed = await compressImage(file);
      execCommand('insertImage', compressed);
    } catch (error) {
      console.error('Image upload failed:', error);
    }
  };

  const getCategoryName = (id: string) => {
    const cat = state.categories.find(c => c.id === id);
    return cat ? (lang === 'ar' ? cat.name : cat.nameEn) : '';
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 animate-fadeIn">
      <div className="sticky top-0 bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 z-10">
        <div className="flex items-center justify-between p-4">
          <button onClick={closeEditor} className="p-2">
            <Icons.Close />
          </button>
          <div className="flex items-center gap-2">
            {isSaving && (
              <span className="text-sm text-green-500 flex items-center gap-1">
                <Icons.Save /> {lang === 'ar' ? 'تم الحفظ' : 'Saved'}
              </span>
            )}
            <button
              onClick={() => {
                const newFavorite = !note.isFavorite;
                if (existingNote) {
                  toggleFavorite(existingNote.id);
                }
                setNote(prev => ({ ...prev, isFavorite: newFavorite }));
              }}
              className={`p-2 ${note.isFavorite ? 'text-amber-500' : ''}`}
            >
              {note.isFavorite ? <Icons.StarFilled /> : <Icons.Star />}
            </button>
            <button
              onClick={() => {
                const newPinned = !note.isPinned;
                if (existingNote) {
                  togglePin(existingNote.id);
                }
                setNote(prev => ({ ...prev, isPinned: newPinned }));
              }}
              className={`p-2 ${note.isPinned ? 'text-indigo-500' : ''}`}
            >
              {note.isPinned ? <Icons.PinFilled /> : <Icons.Pin />}
            </button>
          </div>
        </div>

        <input
          type="text"
          value={note.title || ''}
          onChange={(e) => setNote(prev => ({ ...prev, title: e.target.value }))}
          placeholder={lang === 'ar' ? 'العنوان' : 'Title'}
          className="w-full px-4 pb-2 text-xl font-bold bg-transparent outline-none placeholder-gray-400"
        />

        <div className="flex items-center gap-2 px-4 pb-2 text-sm text-gray-500">
          <button
            onClick={() => setShowTypePicker(true)}
            className="flex items-center gap-1 px-2 py-1 rounded bg-gray-100 dark:bg-gray-800"
          >
            {getNoteTypeIcon(note.type || 'text')} {NOTE_TYPE_LABELS[note.type || 'text'][lang === 'ar' ? 'ar' : 'en']}
          </button>
          <button
            onClick={() => setShowCategoryPicker(true)}
            className="flex items-center gap-1 px-2 py-1 rounded bg-gray-100 dark:bg-gray-800"
          >
            {state.categories.find(c => c.id === note.categoryId)?.icon || '📁'} {getCategoryName(note.categoryId || '')}
          </button>
        </div>
      </div>

      <div className="sticky top-32 bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 z-10 overflow-x-auto">
        <div className="flex items-center gap-1 p-2 min-w-max">
          <button onClick={() => execCommand('bold')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700"><Icons.Bold /></button>
          <button onClick={() => execCommand('italic')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700"><Icons.Italic /></button>
          <button onClick={() => execCommand('underline')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700"><Icons.Underline /></button>
          <button onClick={() => execCommand('strikeThrough')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700"><Icons.Strikethrough /></button>
          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-1" />
          <button onClick={() => execCommand('insertUnorderedList')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700"><Icons.List /></button>
          <button onClick={() => execCommand('insertOrderedList')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700"><Icons.ListOrdered /></button>
          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-1" />
          <button onClick={() => execCommand('formatBlock', 'h1')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-sm font-bold">H1</button>
          <button onClick={() => execCommand('formatBlock', 'h2')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-sm font-bold">H2</button>
          <button onClick={() => execCommand('formatBlock', 'p')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700 text-sm">P</button>
          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-1" />
          <button onClick={() => execCommand('justifyRight')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700"><Icons.AlignRight /></button>
          <button onClick={() => execCommand('justifyCenter')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700"><Icons.AlignCenter /></button>
          <button onClick={() => execCommand('justifyLeft')} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700"><Icons.AlignLeft /></button>
          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600 mx-1" />
          <button onClick={() => setShowColorPicker(true)} className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700">
            <div className="w-5 h-5 rounded border-2" style={{ borderColor: note.color }} />
          </button>
          <label className="p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700 cursor-pointer">
            <Icons.Image />
            <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
          </label>
        </div>
      </div>

      <div className="p-4">
        <div
          ref={contentRef}
          contentEditable
          onInput={handleContentChange}
          className="min-h-64 outline-none prose dark:prose-invert max-w-none"
          dir="auto"
        >
          {existingNote?.content || ''}
        </div>
      </div>

      <div className="px-4 pb-4">
        <div className="flex flex-wrap gap-2 items-center">
          {(note.tags || []).map(tag => (
            <span
              key={tag}
              className="px-2 py-1 bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400 rounded-full text-sm flex items-center gap-1"
            >
              #{tag}
              <button onClick={() => removeTag(tag)} className="hover:text-red-500">
                <Icons.Close />
              </button>
            </span>
          ))}
          <input
            type="text"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addTag()}
            placeholder={lang === 'ar' ? 'إضافة وسم...' : 'Add tag...'}
            className="flex-1 min-w-24 bg-transparent outline-none text-sm"
          />
        </div>
      </div>

      <div className="px-4 pb-4 text-sm text-gray-500">
        {countWords(contentRef.current?.innerHTML || '')} {lang === 'ar' ? 'كلمة' : 'words'} • {countCharacters(contentRef.current?.innerHTML || '')} {lang === 'ar' ? 'حرف' : 'characters'}
      </div>

      {showColorPicker && (
        <Modal onClose={() => setShowColorPicker(false)} title={lang === 'ar' ? 'لون الملاحظة' : 'Note Color'}>
          <div className="grid grid-cols-4 gap-3 p-4">
            {NOTE_COLORS.map(color => (
              <button
                key={color}
                onClick={() => {
                  setNote(prev => ({ ...prev, color }));
                  setShowColorPicker(false);
                }}
                className={`w-12 h-12 rounded-xl ${note.color === color ? 'ring-2 ring-indigo-500 ring-offset-2' : ''}`}
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
        </Modal>
      )}

      {showCategoryPicker && (
        <Modal onClose={() => setShowCategoryPicker(false)} title={lang === 'ar' ? 'الفئة' : 'Category'}>
          <div className="p-4 space-y-1">
            {state.categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => {
                  setNote(prev => ({ ...prev, categoryId: cat.id }));
                  setShowCategoryPicker(false);
                }}
                className={`w-full p-3 rounded-lg flex items-center gap-3 ${
                  note.categoryId === cat.id ? 'bg-indigo-100 dark:bg-indigo-900' : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <span className="text-xl">{cat.icon}</span>
                <span>{lang === 'ar' ? cat.name : cat.nameEn}</span>
                {note.categoryId === cat.id && <Icons.Check />}
              </button>
            ))}
          </div>
        </Modal>
      )}

      {showTypePicker && (
        <Modal onClose={() => setShowTypePicker(false)} title={lang === 'ar' ? 'نوع الملاحظة' : 'Note Type'}>
          <div className="p-4 space-y-1">
            {(Object.keys(NOTE_TYPE_LABELS) as NoteType[]).map(type => (
              <button
                key={type}
                onClick={() => {
                  setNote(prev => ({ ...prev, type }));
                  setShowTypePicker(false);
                }}
                className={`w-full p-3 rounded-lg flex items-center gap-3 ${
                  note.type === type ? 'bg-indigo-100 dark:bg-indigo-900' : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <span>{getNoteTypeIcon(type)}</span>
                <span>{NOTE_TYPE_LABELS[type][lang === 'ar' ? 'ar' : 'en']}</span>
                {note.type === type && <Icons.Check />}
              </button>
            ))}
          </div>
        </Modal>
      )}
    </div>
  );
}

// Search Screen
function SearchScreen() {
  const { state, openEditor, setView, togglePin, toggleFavorite, toggleArchive, deleteNote } = useApp();
  const lang = state.settings.language;
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<'all' | 'favorites' | 'pinned' | 'reminders'>('all');

  const filteredNotes = state.notes.filter(n => !n.isTrashed).filter(n => {
    if (filter === 'favorites') return n.isFavorite;
    if (filter === 'pinned') return n.isPinned;
    if (filter === 'reminders') return n.reminder && n.reminder.dateTime > Date.now();
    return true;
  }).filter(n => {
    if (!query) return true;
    const q = query.toLowerCase();
    return (
      n.title.toLowerCase().includes(q) ||
      n.plainText.toLowerCase().includes(q) ||
      n.tags.some(t => t.toLowerCase().includes(q))
    );
  });

  const getCategoryName = (id: string) => {
    const cat = state.categories.find(c => c.id === id);
    return cat ? (lang === 'ar' ? cat.name : cat.nameEn) : '';
  };

  return (
    <div className="p-4 animate-fadeIn">
      <div className="flex items-center gap-3 mb-4">
        <button onClick={() => setView('home')} className="p-2">
          <Icons.Back />
        </button>
        <div className="flex-1 relative">
          <div className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
            <Icons.Search />
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={lang === 'ar' ? 'البحث في الملاحظات...' : 'Search notes...'}
            className="w-full bg-gray-100 dark:bg-gray-800 rounded-full py-3 px-10 pr-12 outline-none focus:ring-2 focus:ring-indigo-500"
            autoFocus
          />
        </div>
      </div>

      <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
        {[
          { id: 'all', label: lang === 'ar' ? 'الكل' : 'All' },
          { id: 'favorites', label: lang === 'ar' ? 'المفضلة' : 'Favorites' },
          { id: 'pinned', label: lang === 'ar' ? 'المثبتة' : 'Pinned' },
          { id: 'reminders', label: lang === 'ar' ? 'التذكيرات' : 'Reminders' },
        ].map(f => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id as typeof filter)}
            className={`px-4 py-2 rounded-full whitespace-nowrap ${
              filter === f.id
                ? 'bg-indigo-500 text-white'
                : 'bg-gray-100 dark:bg-gray-800'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {filteredNotes.length > 0 ? (
        <div className="space-y-2">
          {filteredNotes.map(note => (
            <NoteCard
              key={note.id}
              note={note}
              onOpen={() => openEditor(note.id)}
              onTogglePin={() => togglePin(note.id)}
              onToggleFavorite={() => toggleFavorite(note.id)}
              onArchive={() => toggleArchive(note.id)}
              onDelete={() => deleteNote(note.id)}
              categoryName={getCategoryName(note.categoryId)}
            />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Icons.Search}
          title={lang === 'ar' ? 'لا توجد نتائج' : 'No results'}
          description={lang === 'ar' ? 'جرب البحث بكلمات مختلفة' : 'Try different keywords'}
        />
      )}
    </div>
  );
}

// Trash Screen
function TrashScreen() {
  const { state, restoreNote, permanentDeleteNote, emptyTrash, setView } = useApp();
  const lang = state.settings.language;
  const trashedNotes = state.notes.filter(n => n.isTrashed);

  return (
    <div className="p-4 animate-fadeIn">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <button onClick={() => setView('home')} className="p-2">
            <Icons.Back />
          </button>
          <h1 className="text-xl font-bold">{lang === 'ar' ? 'المهملات' : 'Trash'}</h1>
        </div>
        {trashedNotes.length > 0 && (
          <button
            onClick={() => {
              if (confirm(lang === 'ar' ? 'هل أنت متأكد من إفراغ المهملات؟' : 'Are you sure you want to empty trash?')) {
                emptyTrash();
              }
            }}
            className="text-red-500 text-sm"
          >
            {lang === 'ar' ? 'إفراغ المهملات' : 'Empty Trash'}
          </button>
        )}
      </div>

      {trashedNotes.length > 0 ? (
        <div className="space-y-2">
          {trashedNotes.map(note => (
            <div
              key={note.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4"
              style={{ borderRight: `4px solid ${note.color || '#EF4444'}` }}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold truncate">{note.title || (lang === 'ar' ? 'بدون عنوان' : 'Untitled')}</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    {lang === 'ar' ? 'حُذفت' : 'Deleted'} {formatRelativeTime(note.trashedAt || 0, lang)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => restoreNote(note.id)}
                    className="p-2 text-green-500 hover:bg-green-50 dark:hover:bg-green-900/30 rounded-lg"
                    title={lang === 'ar' ? 'استعادة' : 'Restore'}
                  >
                    <Icons.Restore />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(lang === 'ar' ? 'هل أنت متأكد من الحذف نهائياً؟' : 'Are you sure you want to permanently delete?')) {
                        permanentDeleteNote(note.id);
                      }
                    }}
                    className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg"
                    title={lang === 'ar' ? 'حذف نهائي' : 'Delete permanently'}
                  >
                    <Icons.Trash />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Icons.TrashEmpty}
          title={lang === 'ar' ? 'المهملات فارغة' : 'Trash is empty'}
          description={lang === 'ar' ? 'الملاحظات المحذوفة ستظهر هنا' : 'Deleted notes will appear here'}
        />
      )}
    </div>
  );
}

// Archive Screen
function ArchiveScreen() {
  const { state, toggleArchive, setView, openEditor, togglePin, toggleFavorite, deleteNote } = useApp();
  const lang = state.settings.language;
  const archivedNotes = state.notes.filter(n => n.isArchived);

  const getCategoryName = (id: string) => {
    const cat = state.categories.find(c => c.id === id);
    return cat ? (lang === 'ar' ? cat.name : cat.nameEn) : '';
  };

  return (
    <div className="p-4 animate-fadeIn">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <button onClick={() => setView('home')} className="p-2">
            <Icons.Back />
          </button>
          <h1 className="text-xl font-bold">{lang === 'ar' ? 'الأرشيف' : 'Archive'}</h1>
        </div>
        <span className="text-sm text-gray-500">{archivedNotes.length}</span>
      </div>

      {archivedNotes.length > 0 ? (
        <div className="space-y-2">
          {archivedNotes.map(note => (
            <NoteCard
              key={note.id}
              note={note}
              onOpen={() => openEditor(note.id)}
              onTogglePin={() => togglePin(note.id)}
              onToggleFavorite={() => toggleFavorite(note.id)}
              onArchive={() => toggleArchive(note.id)}
              onDelete={() => deleteNote(note.id)}
              categoryName={getCategoryName(note.categoryId)}
            />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Icons.Archive}
          title={lang === 'ar' ? 'الأرشيف فارغ' : 'Archive is empty'}
          description={lang === 'ar' ? 'الملاحظات المؤرشفة ستظهر هنا' : 'Archived notes will appear here'}
        />
      )}
    </div>
  );
}

// Empty State Component
function EmptyState({ icon: Icon, title, description, action }: { icon: React.ElementType; title: string; description: string; action?: { label: string; onClick: () => void } }) {
  return (
    <div className="text-center py-12">
      <div className="w-20 h-20 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400">
        <Icon />
      </div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-gray-500 mb-4">{description}</p>
      {action && (
        <button
          onClick={action.onClick}
          className="bg-indigo-500 text-white px-6 py-2 rounded-full"
        >
          {action.label}
        </button>
      )}
    </div>
  );
}

// Modal Component
function Modal({ children, onClose, title }: { children: ReactNode; onClose: () => void; title: string }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/30" />
      <div
        className="relative bg-white dark:bg-gray-800 rounded-t-2xl w-full max-w-md animate-slideUp"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <h3 className="font-semibold">{title}</h3>
          <button onClick={onClose} className="p-1">
            <Icons.Close />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// Main App with Providers
export default function App() {
  return (
    <SettingsProvider>
      <ThemeProvider>
        <AppProvider>
          <AppContent />
        </AppProvider>
      </ThemeProvider>
    </SettingsProvider>
  );
}
