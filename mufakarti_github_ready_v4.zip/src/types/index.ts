export type NoteType = 
  | 'text' 
  | 'task' 
  | 'shopping' 
  | 'ideas' 
  | 'journal' 
  | 'study' 
  | 'work' 
  | 'quick';

export type Priority = 'low' | 'medium' | 'high';
export type RepeatType = 'once' | 'daily' | 'weekly' | 'monthly';
export type ViewMode = 'grid' | 'list';
export type ThemeMode = 'light' | 'dark' | 'system';
export type Language = 'ar' | 'en';

export interface Reminder {
  dateTime: number;
  repeat: RepeatType;
  isTriggered: boolean;
}

export interface Attachment {
  id: string;
  type: 'image' | 'voice' | 'file';
  name: string;
  url: string;
  size: number;
  createdAt: number;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  plainText: string;
  type: NoteType;
  categoryId: string;
  color: string;
  isPinned: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  isTrashed: boolean;
  tags: string[];
  reminder: Reminder | null;
  attachments: Attachment[];
  createdAt: number;
  updatedAt: number;
  trashedAt: number | null;
}

export interface Category {
  id: string;
  name: string;
  nameEn: string;
  icon: string;
  color: string;
  isDefault: boolean;
  order: number;
}

export interface Task {
  id: string;
  noteId: string;
  text: string;
  isCompleted: boolean;
  dueDate: number | null;
  priority: Priority;
  order: number;
  createdAt: number;
}

export interface JournalEntry {
  id: string;
  date: string;
  content: string;
  plainText: string;
  mood: string | null;
  createdAt: number;
  updatedAt: number;
}

export interface AppSettings {
  theme: ThemeMode;
  language: Language;
  accentColor: string;
  fontSize: 'small' | 'medium' | 'large';
  defaultCategory: string;
  defaultView: ViewMode;
  autoSave: boolean;
  autoSaveInterval: number;
  notificationsEnabled: boolean;
  appLockEnabled: boolean;
  pinHash: string | null;
  biometricEnabled: boolean;
  defaultNoteColor: string;
}

export interface SearchFilters {
  query: string;
  type: 'all' | 'favorites' | 'pinned' | 'archived' | 'reminders';
  categoryId: string | null;
  dateRange: { start: number; end: number } | null;
}

export const NOTE_COLORS = [
  '#FFFFFF', // Default white
  '#FEF3C7', // Amber 100
  '#FECACA', // Red 100
  '#DCFCE7', // Green 100
  '#DBEAFE', // Blue 100
  '#E9D5FF', // Purple 100
  '#FED7E2', // Pink 100
  '#FFEDD5', // Orange 100
  '#CFFAFE', // Cyan 100
  '#F0FDFA', // Teal 100
  '#F5F3FF', // Violet 100
  '#FEF9C3', // Yellow 100
];

export const CATEGORY_ICONS = [
  '📁', '📚', '💼', '💡', '✅', '🛒', '✈️', '📝',
  '🎯', '🏠', '❤️', '⭐', '🎨', '🎵', '📷', '💻',
];

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'personal', name: 'شخصي', nameEn: 'Personal', icon: '📁', color: '#6366F1', isDefault: true, order: 0 },
  { id: 'study', name: 'دراسة', nameEn: 'Study', icon: '📚', color: '#8B5CF6', isDefault: true, order: 1 },
  { id: 'work', name: 'عمل', nameEn: 'Work', icon: '💼', color: '#F59E0B', isDefault: true, order: 2 },
  { id: 'ideas', name: 'أفكار', nameEn: 'Ideas', icon: '💡', color: '#10B981', isDefault: true, order: 3 },
  { id: 'tasks', name: 'مهام', nameEn: 'Tasks', icon: '✅', color: '#EF4444', isDefault: true, order: 4 },
  { id: 'shopping', name: 'تسوق', nameEn: 'Shopping', icon: '🛒', color: '#EC4899', isDefault: true, order: 5 },
  { id: 'travel', name: 'سفر', nameEn: 'Travel', icon: '✈️', color: '#06B6D4', isDefault: true, order: 6 },
  { id: 'other', name: 'أخرى', nameEn: 'Other', icon: '📝', color: '#64748B', isDefault: true, order: 7 },
];

export const NOTE_TYPE_LABELS: Record<NoteType, { ar: string; en: string }> = {
  text: { ar: 'نص عادي', en: 'Plain Text' },
  task: { ar: 'قائمة مهام', en: 'Task List' },
  shopping: { ar: 'قائمة تسوق', en: 'Shopping List' },
  ideas: { ar: 'أفكار', en: 'Ideas' },
  journal: { ar: 'مذكرة يومية', en: 'Daily Note' },
  study: { ar: 'دراسة', en: 'Study' },
  work: { ar: 'عمل', en: 'Work' },
  quick: { ar: 'ملاحظة سريعة', en: 'Quick Note' },
};

export const PRIORITY_LABELS: Record<Priority, { ar: string; en: string; color: string }> = {
  low: { ar: 'منخفضة', en: 'Low', color: '#10B981' },
  medium: { ar: 'متوسطة', en: 'Medium', color: '#F59E0B' },
  high: { ar: 'عالية', en: 'High', color: '#EF4444' },
};
