# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keep class com.google.gson.** { *; }
-keep class com.mufakarti.** { *; }
