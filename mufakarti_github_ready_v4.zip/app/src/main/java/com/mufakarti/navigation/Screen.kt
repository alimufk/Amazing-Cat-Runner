package com.mufakarti.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Notes : Screen("notes")
    object Tasks : Screen("tasks")
    object Calendar : Screen("calendar")
    object Settings : Screen("settings")
    object Editor : Screen("editor/{noteId}") {
        fun createRoute(noteId: String) = "editor/$noteId"
    }
    object Search : Screen("search")
    object Trash : Screen("trash")
    object Archive : Screen("archive")
    object Journal : Screen("journal")
    object Categories : Screen("categories")
}
