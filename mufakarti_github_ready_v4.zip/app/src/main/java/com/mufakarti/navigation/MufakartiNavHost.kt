package com.mufakarti.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.mufakarti.ui.screens.ArchiveScreen
import com.mufakarti.ui.screens.CalendarScreen
import com.mufakarti.ui.screens.EditorScreen
import com.mufakarti.ui.screens.HomeScreen
import com.mufakarti.ui.screens.JournalScreen
import com.mufakarti.ui.screens.NotesScreen
import com.mufakarti.ui.screens.SearchScreen
import com.mufakarti.ui.screens.SettingsScreen
import com.mufakarti.ui.screens.TasksScreen
import com.mufakarti.ui.screens.TrashScreen

@Composable
fun MufakartiNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        modifier = modifier
    ) {
        composable(Screen.Home.route) {
            HomeScreen(navController = navController)
        }
        composable(Screen.Notes.route) {
            NotesScreen(navController = navController)
        }
        composable(Screen.Tasks.route) {
            TasksScreen(navController = navController)
        }
        composable(Screen.Calendar.route) {
            CalendarScreen(navController = navController)
        }
        composable(Screen.Settings.route) {
            SettingsScreen(navController = navController)
        }
        composable(Screen.Search.route) {
            SearchScreen(navController = navController)
        }
        composable(Screen.Trash.route) {
            TrashScreen(navController = navController)
        }
        composable(Screen.Archive.route) {
            ArchiveScreen(navController = navController)
        }
        composable(Screen.Journal.route) {
            JournalScreen(navController = navController)
        }
        composable(
            route = Screen.Editor.route,
            arguments = listOf(navArgument("noteId") {
                type = NavType.StringType
                nullable = true
                defaultValue = ""
            })
        ) { backStackEntry ->
            val noteId = backStackEntry.arguments?.getString("noteId") ?: ""
            EditorScreen(navController = navController, noteId = noteId)
        }
    }
}
