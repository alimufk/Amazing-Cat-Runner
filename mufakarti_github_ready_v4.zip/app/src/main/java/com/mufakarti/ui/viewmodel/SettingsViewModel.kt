package com.mufakarti.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mufakarti.data.datastore.AppSettings
import com.mufakarti.data.datastore.SettingsDataStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsDataStore: SettingsDataStore
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsDataStore.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AppSettings()
    )

    fun updateTheme(theme: String) {
        viewModelScope.launch { settingsDataStore.updateTheme(theme) }
    }

    fun updateLanguage(language: String) {
        viewModelScope.launch { settingsDataStore.updateLanguage(language) }
    }

    fun updateFontSize(size: String) {
        viewModelScope.launch { settingsDataStore.updateFontSize(size) }
    }

    fun updateAccentColor(color: String) {
        viewModelScope.launch { settingsDataStore.updateAccentColor(color) }
    }

    fun updateDefaultCategory(category: String) {
        viewModelScope.launch { settingsDataStore.updateDefaultCategory(category) }
    }

    fun updateDefaultView(view: String) {
        viewModelScope.launch { settingsDataStore.updateDefaultView(view) }
    }

    fun updateAutoSave(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.updateAutoSave(enabled) }
    }

    fun updateNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.updateNotificationsEnabled(enabled) }
    }

    fun updateAppLockEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.updateAppLockEnabled(enabled) }
    }

    fun updateBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsDataStore.updateBiometricEnabled(enabled) }
    }
}
