package com.mufakarti.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mufakarti.data.model.Note
import com.mufakarti.data.repository.NoteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NoteViewModel @Inject constructor(
    private val noteRepository: NoteRepository
) : ViewModel() {

    val allNotes: StateFlow<List<Note>> = noteRepository.allNotes.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val trashedNotes: StateFlow<List<Note>> = noteRepository.trashedNotes.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val archivedNotes: StateFlow<List<Note>> = noteRepository.archivedNotes.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val pinnedNotes: StateFlow<List<Note>> = noteRepository.pinnedNotes.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notesCount: StateFlow<Int> = noteRepository.notesCount.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    fun insertNote(note: Note) {
        viewModelScope.launch { noteRepository.insertNote(note) }
    }

    fun updateNote(note: Note) {
        viewModelScope.launch { noteRepository.updateNote(note) }
    }

    fun moveToTrash(note: Note) {
        viewModelScope.launch { noteRepository.moveToTrash(note) }
    }

    fun restoreFromTrash(note: Note) {
        viewModelScope.launch { noteRepository.restoreFromTrash(note) }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch { noteRepository.deleteNote(note) }
    }

    fun togglePin(note: Note) {
        viewModelScope.launch { noteRepository.togglePin(note) }
    }

    fun toggleFavorite(note: Note) {
        viewModelScope.launch { noteRepository.toggleFavorite(note) }
    }

    fun toggleArchive(note: Note) {
        viewModelScope.launch { noteRepository.toggleArchive(note) }
    }

    fun emptyTrash() {
        viewModelScope.launch { noteRepository.emptyTrash() }
    }

    suspend fun getNoteById(id: String): Note? = noteRepository.getNoteById(id)
}
