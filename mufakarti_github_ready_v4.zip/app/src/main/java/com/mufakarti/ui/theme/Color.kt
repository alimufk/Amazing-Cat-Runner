package com.mufakarti.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Colors
val IndigoPrimary = Color(0xFF6366F1)
val IndigoDark = Color(0xFF4338CA)
val IndigoLight = Color(0xFF818CF8)
val PurpleSecondary = Color(0xFF8B5CF6)
val PurpleLight = Color(0xFFA78BFA)
val AmberAccent = Color(0xFFF59E0B)
val AmberLight = Color(0xFFFBBF24)

// Surfaces
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)

// Text
val TextPrimary = Color(0xFF1E293B)
val TextSecondary = Color(0xFF64748B)
val TextDarkPrimary = Color(0xFFF1F5F9)
val TextDarkSecondary = Color(0xFF94A3B8)

// Semantic
val Success = Color(0xFF10B981)
val Warning = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
val ErrorLight = Color(0xFFF87171)

// Note Colors
val NoteDefaultWhite = Color(0xFFFFFFFF)
val NoteAmber = Color(0xFFFEF3C7)
val NoteRed = Color(0xFFFECACA)
val NoteGreen = Color(0xFFDCFCE7)
val NoteBlue = Color(0xFFDBEAFE)
val NotePurple = Color(0xFFE9D5FF)
val NotePink = Color(0xFFFED7E2)
val NoteOrange = Color(0xFFFFEDD5)
val NoteCyan = Color(0xFFCFFAFE)
val NoteTeal = Color(0xFFF0FDFA)
val NoteViolet = Color(0xFFF5F3FF)
val NoteYellow = Color(0xFFFEF9C3)
