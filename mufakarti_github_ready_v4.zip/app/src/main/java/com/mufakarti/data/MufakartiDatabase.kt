package com.mufakarti.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.mufakarti.data.dao.CategoryDao
import com.mufakarti.data.dao.JournalDao
import com.mufakarti.data.dao.NoteDao
import com.mufakarti.data.dao.TaskDao
import com.mufakarti.data.model.Category
import com.mufakarti.data.model.JournalEntry
import com.mufakarti.data.model.Note
import com.mufakarti.data.model.Task

@Database(
    entities = [Note::class, Task::class, Category::class, JournalEntry::class],
    version = 1,
    exportSchema = false
)
abstract class MufakartiDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun taskDao(): TaskDao
    abstract fun categoryDao(): CategoryDao
    abstract fun journalDao(): JournalDao

    companion object {
        const val DATABASE_NAME = "mufakarti.db"
    }
}
