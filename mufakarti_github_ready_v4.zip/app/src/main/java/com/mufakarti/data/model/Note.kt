package com.mufakarti.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class NoteType {
    TEXT, TASK, SHOPPING, IDEAS, JOURNAL, STUDY, WORK, QUICK
}

enum class Priority {
    LOW, MEDIUM, HIGH
}

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey val id: String,
    val title: String,
    val content: String,
    val plainText: String,
    val type: String,
    val categoryId: String,
    val color: String,
    val isPinned: Boolean = false,
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,
    val isTrashed: Boolean = false,
    val tags: String = "",
    val reminderTime: Long? = null,
    val reminderRepeat: String? = null,
    val createdAt: Long,
    val updatedAt: Long,
    val trashedAt: Long? = null
)

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey val id: String,
    val noteId: String,
    val text: String,
    val isCompleted: Boolean = false,
    val dueDate: Long? = null,
    val priority: String = "MEDIUM",
    val order: Int = 0,
    val createdAt: Long
)

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey val id: String,
    val name: String,
    val nameEn: String,
    val icon: String,
    val color: String,
    val isDefault: Boolean = false,
    val order: Int = 0
)

@Entity(tableName = "journal_entries")
data class JournalEntry(
    @PrimaryKey val date: String,
    val content: String,
    val plainText: String,
    val mood: String? = null,
    val createdAt: Long,
    val updatedAt: Long
)
