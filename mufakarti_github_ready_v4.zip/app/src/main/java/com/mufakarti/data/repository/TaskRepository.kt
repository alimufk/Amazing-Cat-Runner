package com.mufakarti.data.repository

import com.mufakarti.data.dao.TaskDao
import com.mufakarti.data.model.Task
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TaskRepository @Inject constructor(
    private val taskDao: TaskDao
) {
    val allTasks: Flow<List<Task>> = taskDao.getAllTasks()
    val pendingTasks: Flow<List<Task>> = taskDao.getPendingTasks()

    fun getTasksByNoteId(noteId: String): Flow<List<Task>> = taskDao.getTasksByNoteId(noteId)

    suspend fun insertTask(task: Task) = taskDao.insertTask(task)

    suspend fun updateTask(task: Task) = taskDao.updateTask(task)

    suspend fun deleteTask(task: Task) = taskDao.deleteTask(task)

    suspend fun toggleTask(task: Task) {
        taskDao.updateTask(task.copy(isCompleted = !task.isCompleted))
    }
}
