package com.mufakarti.data.repository

import com.mufakarti.data.dao.JournalDao
import com.mufakarti.data.model.JournalEntry
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class JournalRepository @Inject constructor(
    private val journalDao: JournalDao
) {
    val allEntries: Flow<List<JournalEntry>> = journalDao.getAllEntries()

    suspend fun getEntryByDate(date: String): JournalEntry? = journalDao.getEntryByDate(date)

    suspend fun insertEntry(entry: JournalEntry) = journalDao.insertEntry(entry)

    suspend fun deleteEntry(date: String) = journalDao.deleteEntry(date)
}
