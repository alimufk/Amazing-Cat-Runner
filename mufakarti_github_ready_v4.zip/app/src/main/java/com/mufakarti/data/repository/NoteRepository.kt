package com.mufakarti.data.repository

import com.mufakarti.data.dao.NoteDao
import com.mufakarti.data.model.Note
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NoteRepository @Inject constructor(
    private val noteDao: NoteDao
) {
    val allNotes: Flow<List<Note>> = noteDao.getAllNotes()
    val trashedNotes: Flow<List<Note>> = noteDao.getTrashedNotes()
    val archivedNotes: Flow<List<Note>> = noteDao.getArchivedNotes()
    val pinnedNotes: Flow<List<Note>> = noteDao.getPinnedNotes()
    val favoriteNotes: Flow<List<Note>> = noteDao.getFavoriteNotes()
    val notesCount: Flow<Int> = noteDao.getNotesCount()

    fun searchNotes(query: String): Flow<List<Note>> {
        return noteDao.searchNotes("%$query%")
    }

    fun getNotesByCategory(categoryId: String): Flow<List<Note>> {
        return noteDao.getNotesByCategory(categoryId)
    }

    suspend fun getNoteById(id: String): Note? = noteDao.getNoteById(id)

    suspend fun insertNote(note: Note) = noteDao.insertNote(note)

    suspend fun updateNote(note: Note) = noteDao.updateNote(note)

    suspend fun deleteNote(note: Note) = noteDao.deleteNote(note)

    suspend fun moveToTrash(note: Note) {
        noteDao.updateNote(note.copy(isTrashed = true, trashedAt = System.currentTimeMillis()))
    }

    suspend fun restoreFromTrash(note: Note) {
        noteDao.updateNote(note.copy(isTrashed = false, trashedAt = null))
    }

    suspend fun togglePin(note: Note) {
        noteDao.updateNote(note.copy(isPinned = !note.isPinned))
    }

    suspend fun toggleFavorite(note: Note) {
        noteDao.updateNote(note.copy(isFavorite = !note.isFavorite))
    }

    suspend fun toggleArchive(note: Note) {
        noteDao.updateNote(note.copy(isArchived = !note.isArchived, isPinned = false))
    }

    suspend fun emptyTrash() = noteDao.emptyTrash()
}
