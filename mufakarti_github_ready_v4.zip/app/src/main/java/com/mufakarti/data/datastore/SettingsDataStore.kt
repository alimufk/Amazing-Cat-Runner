package com.mufakarti.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "mufakarti_settings")

data class AppSettings(
    val theme: String = "system",          // light, dark, system
    val language: String = "ar",          // ar, en
    val fontSize: String = "medium",      // small, medium, large
    val accentColor: String = "indigo",   // indigo, purple, pink, red, amber, green, cyan, blue
    val defaultCategory: String = "personal",
    val defaultView: String = "grid",     // grid, list
    val autoSave: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val appLockEnabled: Boolean = false,
    val biometricEnabled: Boolean = false,
    val defaultNoteColor: String = "#FFFFFF"
)

@Singleton
class SettingsDataStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val dataStore = context.settingsDataStore

    private object Keys {
        val THEME = stringPreferencesKey("theme")
        val LANGUAGE = stringPreferencesKey("language")
        val FONT_SIZE = stringPreferencesKey("font_size")
        val ACCENT_COLOR = stringPreferencesKey("accent_color")
        val DEFAULT_CATEGORY = stringPreferencesKey("default_category")
        val DEFAULT_VIEW = stringPreferencesKey("default_view")
        val AUTO_SAVE = booleanPreferencesKey("auto_save")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val APP_LOCK_ENABLED = booleanPreferencesKey("app_lock_enabled")
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        val DEFAULT_NOTE_COLOR = stringPreferencesKey("default_note_color")
    }

    val settings: Flow<AppSettings> = dataStore.data.map { prefs ->
        AppSettings(
            theme = prefs[Keys.THEME] ?: "system",
            language = prefs[Keys.LANGUAGE] ?: "ar",
            fontSize = prefs[Keys.FONT_SIZE] ?: "medium",
            accentColor = prefs[Keys.ACCENT_COLOR] ?: "indigo",
            defaultCategory = prefs[Keys.DEFAULT_CATEGORY] ?: "personal",
            defaultView = prefs[Keys.DEFAULT_VIEW] ?: "grid",
            autoSave = prefs[Keys.AUTO_SAVE] ?: true,
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
            appLockEnabled = prefs[Keys.APP_LOCK_ENABLED] ?: false,
            biometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: false,
            defaultNoteColor = prefs[Keys.DEFAULT_NOTE_COLOR] ?: "#FFFFFF"
        )
    }

    suspend fun updateTheme(theme: String) {
        dataStore.edit { it[Keys.THEME] = theme }
    }

    suspend fun updateLanguage(language: String) {
        dataStore.edit { it[Keys.LANGUAGE] = language }
    }

    suspend fun updateFontSize(size: String) {
        dataStore.edit { it[Keys.FONT_SIZE] = size }
    }

    suspend fun updateAccentColor(color: String) {
        dataStore.edit { it[Keys.ACCENT_COLOR] = color }
    }

    suspend fun updateDefaultCategory(category: String) {
        dataStore.edit { it[Keys.DEFAULT_CATEGORY] = category }
    }

    suspend fun updateDefaultView(view: String) {
        dataStore.edit { it[Keys.DEFAULT_VIEW] = view }
    }

    suspend fun updateAutoSave(enabled: Boolean) {
        dataStore.edit { it[Keys.AUTO_SAVE] = enabled }
    }

    suspend fun updateNotificationsEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    suspend fun updateAppLockEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.APP_LOCK_ENABLED] = enabled }
    }

    suspend fun updateBiometricEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.BIOMETRIC_ENABLED] = enabled }
    }

    suspend fun updateDefaultNoteColor(color: String) {
        dataStore.edit { it[Keys.DEFAULT_NOTE_COLOR] = color }
    }

    suspend fun clearAll() {
        dataStore.edit { it.clear() }
    }
}
