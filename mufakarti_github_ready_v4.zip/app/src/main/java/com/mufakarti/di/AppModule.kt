package com.mufakarti.di

import android.content.Context
import androidx.room.Room
import com.mufakarti.data.MufakartiDatabase
import com.mufakarti.data.dao.CategoryDao
import com.mufakarti.data.dao.JournalDao
import com.mufakarti.data.dao.NoteDao
import com.mufakarti.data.dao.TaskDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): MufakartiDatabase {
        return Room.databaseBuilder(
            context,
            MufakartiDatabase::class.java,
            MufakartiDatabase.DATABASE_NAME
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    @Singleton
    fun provideNoteDao(database: MufakartiDatabase): NoteDao = database.noteDao()

    @Provides
    @Singleton
    fun provideTaskDao(database: MufakartiDatabase): TaskDao = database.taskDao()

    @Provides
    @Singleton
    fun provideCategoryDao(database: MufakartiDatabase): CategoryDao = database.categoryDao()

    @Provides
    @Singleton
    fun provideJournalDao(database: MufakartiDatabase): JournalDao = database.journalDao()
}
