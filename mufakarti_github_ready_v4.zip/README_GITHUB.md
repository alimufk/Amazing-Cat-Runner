# مفكرتي - Mufakarti

نسخة Android معدّة للبناء عبر GitHub Actions.

## البناء
1. ارفع ملف ZIP إلى مستودع GitHub.
2. افتح Actions.
3. اختر Build Mufakarti APK.
4. اضغط Run workflow.
5. بعد نجاح البناء افتح Artifacts ثم Mufakarti-APK.

تم تفعيل AndroidX وJetifier داخل `gradle.properties`.

المطور: علاوي النعيمي
