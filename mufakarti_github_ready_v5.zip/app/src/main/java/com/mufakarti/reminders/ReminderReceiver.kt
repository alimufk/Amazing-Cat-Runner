package com.mufakarti.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Reminder receiver placeholder; safe no-op until reminder scheduling is implemented.
    }
}
